<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/
//Fake routes
Route::get('/removeSlashFromTagSlug', 'HelperController@removeSlashFromTagSlug');
Route::get('/reResizePostThumb', 'HelperController@reResizePostThumb');
Route::get('/changeImagesToHttps', 'HelperController@changeImagesToHttps');
Route::get('/generateSitemap', 'HelperController@generateSitemap');
Route::get('/updatePostViews', 'HelperController@updatePostViews');

Route::group(['prefix' => 'cms', 'namespace' => 'CMS'], function () {
    //Auth
    Route::group(['middleware' => 'auth:sanctum'], function () {
        Route::post('/images/upload', 'ImageController@upload');
        Route::post('/images/delete', 'ImageController@delete');
        Route::get('/user/auth', 'AuthController@user');
        Route::get('/logout', 'AuthController@logout');
        Route::post('/setting/password/change', 'AuthController@changePassword');
        //Role
        Route::get('/role/list', 'RoleController@list')->middleware('can:roles.list');
        Route::post('/role/add', 'RoleController@add')->middleware('can:roles.add');
        Route::post('/role/edit/{id}', 'RoleController@edit')->middleware('can:roles.edit');
        Route::get('/role/delete/{id}', 'RoleController@delete')->middleware('can:roles.delete');
        //User
        Route::post('/user/list', 'UserController@list')->middleware('can:users.list');
        Route::post('/user/add', 'UserController@add')->middleware('can:users.add');
        Route::post('/user/edit/{id}', 'UserController@edit')->middleware('can:users.edit');
        Route::get('/user/delete/{id}', 'UserController@delete')->middleware('can:users.delete');
        //Folder
        Route::post('/folder/rearrange', 'FolderController@rearrange')->middleware('can:users.add');
        Route::get('/folder/list', 'FolderController@list')->middleware('can:folders.list');
        Route::post('/folder/add', 'FolderController@add')->middleware('can:folders.add');
        Route::post('/folder/edit/{id}', 'FolderController@edit')->middleware('can:folders.edit');
        Route::post('/folder/header/search', 'FolderController@searchFoldersForHeader')->middleware('can:posts.list_editor');
        Route::get('/folder/header/top_folders', 'FolderController@getTopFoldersForHeader')->middleware('can:posts.list_editor');
        Route::post('/folder/header/change_header', 'FolderController@changeFolderHeader')->middleware('can:posts.list_editor');
        //Post
        Route::post('/post/list', 'PostController@list');
        Route::post('/post/exportExcel', 'PostController@exportExcel')->middleware('can:posts.list_editor');;
        Route::post('/post/add', 'PostController@add')->middleware('can:posts.add');
        Route::get('/post/add/recent_folders', 'PostController@getRecentFolders')->middleware('can:posts.add');
        Route::post('/post/add/tag_list', 'PostController@listTags')->middleware('can:posts.add');
        Route::post('/post/add/tag_add', 'PostController@addTag')->middleware('can:posts.add');
        Route::post('/post/add/folder_search', 'PostController@searchFolders')->middleware('can:posts.add');
        Route::post('/post/edit/{id}', 'PostController@edit')->middleware('can:posts.edit');
        Route::get('/post/detail/{id}', 'PostController@detail');
        Route::post('/post/changeVerticalThumb/{id}', 'PostController@changeVerticalThumb');
        Route::post('/post/changeSquareThumb/{id}', 'PostController@changeSquareThumb');
        Route::post('/post/delete', 'PostController@delete');
        Route::post('/post/publish', 'PostController@publish');
        //Builds
        Route::post('/build/post/search', 'BuildController@searchPost');
        //top
        Route::get('/build/top/get', 'BuildController@getTop')->middleware('can:builds.top');
        Route::post('/build/top/change', 'BuildController@changeTop')->middleware('can:builds.top');
        //hot
        Route::get('/build/hot/get', 'BuildController@getHot')->middleware('can:builds.hot');
        Route::post('/build/hot/change', 'BuildController@changeHot')->middleware('can:builds.hot');
        //trend
        Route::get('/build/trend/get', 'BuildController@getTrend')->middleware('can:builds.trend');
        Route::post('/build/trend/change', 'BuildController@changeTrend')->middleware('can:builds.trend');
        //folder
        Route::get('/build/list/folders', 'BuildController@listFolders');
        Route::post('/build/posts/folder', 'BuildController@getFolderPostsBuild');
        Route::post('/build/folder/posts', 'BuildController@buildForFolder');
        //Campaign
        Route::post('/campaign/partners/add', 'CampaignController@addPartner');
        Route::post('/campaign/contacts/add', 'CampaignController@addContact');
        Route::post('/campaign/partners/filter', 'CampaignController@filterPartners');
        Route::post('/campaign/pr_post/list', 'CampaignController@listPRPost');
        Route::post('/campaign/pr_post/add', 'CampaignController@addPRToCampaign');
        Route::post('/campaign/pr_post/add_campaign_to_post', 'CampaignController@addCampaignToPost');

        Route::post('/campaign/all', 'CampaignController@all');
        Route::get('/campaign/detail/{campaign_id}', 'CampaignController@detail');
        Route::post('/campaign/campaigns/add', 'CampaignController@add');
        Route::post('/banner/list', 'CampaignController@listBanners');
    });
    //Not auth
    Route::post('/images/editor/upload', 'ImageController@uploadEditor');
    //List all editor images
    Route::get('/images/editor/list', 'ImageController@listEditorImages');
    //Delete editor image
    Route::post('/images/editor/delete', 'ImageController@deleteEditorImage');
    Route::post('/login', 'AuthController@login');
    Route::get('/permissions/list', function () {
        return config('permissions');
    });
});

Route::group(['prefix' => 'front', 'namespace' => 'Front'], function () {
    //Auth
    Route::group(['middleware' => 'auth:sanctum'], function () {
        //Images
        Route::post('/images/upload', 'ImageController@upload');
        //user
        Route::get('/user', 'AuthController@user');
        Route::post('/user/account/changeInfo', 'AuthController@changeInfo');
        Route::get('/logout', 'AuthController@logout');
        //comment
        Route::post('/comment/add', 'CommentController@add');
        Route::get('/comment/delete/{comment_id}', 'CommentController@delete');
        //like
        Route::get('/comment/like/{comment_id}', 'CommentController@like');
        Route::post('/comment/checkLike', 'CommentController@checkLike');
        //My account
        Route::get('/myAccount/info', 'UserController@myAccountInfo');
        Route::get('/myAccount/seenPosts', 'UserController@myAccountSeenPosts');
        //Seen post
        Route::get('/seenPost/{post_id}', 'UserController@seenPost');
        //Notifications
        Route::get('/notification/all', 'NotificationController@all');
        Route::get('/notification/unseenCount', 'NotificationController@unseenCount');
        Route::get('/notification/read/{notification_id}', 'NotificationController@read');
    });
    //Not auth
    //Login, logout
    Route::post('/login', 'AuthController@login');
    Route::post('/login/apple', 'AuthController@loginApple');
    //List folders header
    Route::get('/header/folders/list', 'HomeController@listFoldersHeader');
    //Home page
    Route::get('/home/posts/topping', 'HomeController@toppingPosts');
    Route::post('/home/posts/new', 'HomeController@newPosts');
    Route::get('/home/topFolders/first', 'HomeController@getFirstTopFolders');
    Route::get('/home/topFolders/second', 'HomeController@getSecondTopFolders');
    Route::get('/home/banners/all', 'HomeController@getBanners');
    Route::get('/home/videos/all', 'HomeController@getVideos');
    //Folder
    Route::get('/folder/topping/{folder_id}', 'FolderController@topping');
    Route::get('/folder/banners/{folder_id}', 'FolderController@banners');
    Route::get('/folder/posts/{folder_id}', 'FolderController@posts');
    //Tag
    Route::get('/tag/posts/{tag_slug}', 'FolderController@tagPosts');
    Route::get('/tag/banners/{tag_id}', 'FolderController@tagBanners');
    //Post
    Route::get('/post/detail/{post_id}', 'PostController@detail');
    Route::get('/post/banners/{post_id}', 'PostController@banners');
    Route::get('/post/related/{post_id}', 'PostController@related');
    Route::post('/post/recommended/{post_id}', 'PostController@recommended');
    //Comment
    Route::get('/comment/list/{post_id}', 'CommentController@list');
    Route::get('/comment/child_list/{parent_id}', 'CommentController@listChild');
    //Check Object Type
    Route::post('/checkObjectType1', 'XamXiController@checkObjectType');
    //Get User Info
    Route::get('/user/detail/{user_id}', 'UserController@detail');
//    //Campaign
    Route::get('/banners/list', 'CampaignController@listBanners');
    Route::post('/campaign/campaigns/click_pc', 'CampaignController@clickPC');
    Route::post('/campaign/campaigns/click_mb', 'CampaignController@clickMB');
    Route::post('/campaign/campaigns/impress_pc', 'CampaignController@impressPC');
    Route::post('/campaign/campaigns/impress_mb', 'CampaignController@impressMB');
});
