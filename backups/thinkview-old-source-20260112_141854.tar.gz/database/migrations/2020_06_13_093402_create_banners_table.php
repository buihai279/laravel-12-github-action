<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateBannersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('banners', function (Blueprint $table) {
            $table->id();
            $table->string('image_pc')->nullable();
            $table->string('image_mb')->nullable();
            $table->integer('type')->default(1);
            $table->string('link')->nullable();
            $table->unsignedBigInteger('campaign_id');
            $table->integer('impressions_mb')->default(0);
            $table->integer('impressions_pc')->default(0);
            $table->integer('clicks_mb')->default(0);
            $table->integer('clicks_pc')->default(0);
            $table->integer('slot')->default(1);
            $table->string('folder_id')->default(serialize([]));

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('banners');
    }
}
