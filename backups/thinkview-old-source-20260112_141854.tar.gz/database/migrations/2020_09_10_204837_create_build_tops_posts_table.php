<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateBuildTopsPostsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('build_tops_posts', function (Blueprint $table) {
            $table->bigInteger('build_top_id')->unsigned();
            $table->bigInteger('post_id')->unsigned();
            $table->unique(['build_top_id', 'post_id']);

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('build_tops_posts');
    }
}
