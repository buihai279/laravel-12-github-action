<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePostsListOnFoldersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('posts_list_on_folders', function (Blueprint $table) {
            $table->bigInteger('post_id')->unsigned();
            $table->bigInteger('folder_id')->unsigned();
            $table->unique(['post_id', 'folder_id']);

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('posts_list_on_folders');
    }
}
