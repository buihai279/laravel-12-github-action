<?php

namespace Database\Factories\Model;

use App\Model\Folder;
use App\Model\Post;
use App\Model\Tag;
use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Str;

class PostFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = Post::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        $faker = $this->faker;
        $set_on_id = \App\Model\Folder::inRandomOrder()->first()->id;
        $cover = 'uploads/cover.jpg';
        $thumbnail = 'uploads/thumbnail.jpg';
        $title = $faker->sentence(10);
        return [
            'title' => $title,
            'description' => $faker->paragraph(3),
            'content' => $faker->randomHtml(5, 5),
            'set_on_id' => $set_on_id,
            'created_by_id' => 1,
            'cover' => $cover,
            'thumbnail' => $thumbnail,
            'priority' => $faker->numberBetween(1, 3),
            'published_at' => now(),
            'status' => $faker->numberBetween(0, 3),
            'keywords' => serialize(['Ngon', 'Bổ', 'Rẻ']),
            'is_sponsored' => $faker->numberBetween(0, 1),
            'published_by_id' => 1,
        ];
    }

    public function configure()
    {
        return $this->afterCreating(function (Post $post) {
            $faker = $this->faker;
            $set_on_id = $post->set_on_id;
            $list_on_ids = Folder::where('id', '!=', $set_on_id)->inRandomOrder()->take($faker->numberBetween(2, 5))->pluck('id')->toArray();
            $tags = Tag::inRandomOrder()->take($faker->numberBetween(1, 3))->pluck('id')->toArray();
            $post->list_on_folders()->attach($list_on_ids);
            $post->tags()->attach($tags);
            $post->slug = Str::slug($post->title) . '-' . $post->id . '.html';
            $post->save();
        });
    }
}
