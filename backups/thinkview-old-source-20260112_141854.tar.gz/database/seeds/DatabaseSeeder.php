<?php

use App\Model\Folder;
use App\Model\Role;
use App\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Str;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        // $this->call(UserSeeder::class);
        Role::create([
            'name' => 'Admin',
            'permissions' => serialize([
                'roles.add',
                'roles.edit',
                'roles.list',
                'roles.delete',

                'users.add',
                'users.edit',
                'users.list',
                'users.delete',

                'builds.top',
                'builds.hot',
                'builds.trend',

                'folders.add',
                'folders.edit',
                'folders.list',
                'folders.delete',

                'posts.add',
                'posts.edit',
                'posts.list',
                'posts.delete',
                'posts.list_writer',
                'posts.list_editor',
                'posts.publish',
            ]),
            'created_by_id' => 1
        ]);

        Role::create([
            'name' => 'Editor',
            'permissions' => serialize([
                'roles.add',
                'roles.edit',
                'roles.list',
                'roles.delete',

                'users.add',
                'users.edit',
                'users.list',
                'users.delete',

                'builds.top',
                'builds.hot',
                'builds.trend',

                'folders.add',
                'folders.edit',
                'folders.list',
                'folders.delete',

                'posts.add',
                'posts.edit',
                'posts.list',
                'posts.delete',
                'posts.list_writer',
                'posts.list_editor',
                'posts.publish',
            ]),
            'created_by_id' => 1
        ]);

        User::create([
            'email' => 'admin@thinkview.vn',
            'name' => 'Admin',
            'password' => bcrypt('admin'),
            'role_id' => 1
        ]);

        $folders = [
            'Laptop' => [
                'Văn phòng', 'Gaming', 'Workstation'
            ],
            'Điện thoại' => [
                'Android', 'Apple', 'Tư vấn chọn mua điện thoại'
            ],
            'Gear' => [
                'Màn hình', 'Bàn phím, chuột', 'Đồ chơi', 'Tai nghe', 'Loa'
            ],
            'PC' => [
                'Gaming PC', 'Văn Phòng', 'Workstation', 'Multimedia', 'Giải pháp, tư vấn'
            ],
            'Game' => [
                'Đánh giá game', 'Tin tức', 'Câu chuyện game thủ'
            ],
        ];
        \App\Model\BuildTop::create([]);
        \App\Model\BuildHot::create([]);
        \App\Model\BuildTrend::create([]);
        foreach ($folders as $folder0 => $folder0_children) {
            $f0 = Folder::create(
                [
                    'name' => $folder0,
                    'parent_id' => null,
                    'level' => 1,
                    'slug' => Str::slug($folder0),
                    'created_by_id' => 1,
                ]
            );
            foreach ($folder0_children as $folder0_child) {
                Folder::create(
                    [
                        'name' => $folder0_child,
                        'parent_id' => $f0->id,
                        'level' => 2,
                        'slug' => Str::slug($folder0) . '/' . Str::slug($folder0_child),
                        'created_by_id' => 1,
                    ]
                );
            }
        }
//        \App\Model\Banner::create([
//            'name' => 'Break page large',
//            'position' => 1,
//            'size' => '1208x302',
//            'sticky' => false,
//            'internal_link' => true,
//            'external_link' => true,
//            'number_slots' => 1
//        ]);
//        \App\Model\Banner::create([
//            'name' => 'Verticle display - large',
//            'position' => 1,
//            'size' => '368x736',
//            'sticky' => true,
//            'internal_link' => true,
//            'external_link' => true,
//            'number_slots' => 1
//        ]);
//        \App\Model\Banner::create([
//            'name' => 'Medium display',
//            'position' => 1,
//            'size' => '368x207',
//            'sticky' => false,
//            'internal_link' => true,
//            'external_link' => false,
//            'number_slots' => 3
//        ]);
//        \App\Model\Banner::create([
//            'name' => 'Native article box',
//            'position' => 1,
//            'size' => '368x207',
//            'sticky' => true,
//            'internal_link' => true,
//            'external_link' => false,
//            'number_slots' => 1
//        ]);
//        \App\Model\Banner::create([
//            'name' => 'Product listing',
//            'position' => 1,
//            'size' => '80x80',
//            'sticky' => true,
//            'internal_link' => false,
//            'external_link' => true,
//            'number_slots' => 1
//        ]);
        $tags = [
            ['name' => "ThinkView 1", 'slug' => 'thinkview-1', 'description' => 'ThinkView 1', 'created_by_id' => 1],
            ['name' => "ThinkView 2", 'slug' => 'thinkview-2', 'description' => 'ThinkView 2', 'created_by_id' => 1],
            ['name' => "ThinkView 3", 'slug' => 'thinkview-3', 'description' => 'ThinkView 3', 'created_by_id' => 1],
            ['name' => "ThinkView 4", 'slug' => 'thinkview-4', 'description' => 'ThinkView 4', 'created_by_id' => 1],
            ['name' => "ThinkView 5", 'slug' => 'thinkview-5', 'description' => 'ThinkView 5', 'created_by_id' => 1],
        ];
        \App\Model\Tag::insert($tags);

        \App\Model\Post::factory()->count(1000)->create();
    }
}
