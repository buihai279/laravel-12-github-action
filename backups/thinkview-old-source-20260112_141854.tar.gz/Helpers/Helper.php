<?php

namespace App\Helpers;

use Carbon\Carbon;
use Carbon\CarbonInterval;

class Helper
{
    public static function formatDate($time = '', $type = 1)
    {
        $time = Carbon::parse($time);
        if ($type == 1) {
            return str_replace('trước', '', $time->diffForHumans());
        }
        if ($type == 2) {
            $gio = $time->hour;
            $phut = $time->minute;
            return $gio . ':' . $phut;
        }
        if ($type == 3) {
            return $time->diffForHumans();
        }
        if ($type == 4) {
            $ngay = $time->day;
            $thang = $time->month;
            $nam = $time->year;
            return $ngay . '/' . $thang . '/' . $nam;
        }
    }

    public static function advFormatDate($time)
    {
        $time = Carbon::parse($time);
        $thu = $time->dayOfWeek + 1;
        $ngay = $time->day;
        $thang = $time->month;
        $nam = $time->year;
        $gio = $time->hour;
        $phut = $time->minute;
        $ngayTrongTuan = [
            2 => 'Thứ Hai',
            3 => 'Thứ Ba',
            4 => 'Thứ Tư',
            5 => 'Thứ Năm',
            6 => 'Thứ Sáu',
            7 => 'Thứ Bảy',
            1 => 'Chủ nhật'
        ];
        return $ngayTrongTuan[$thu] . ', ' . $ngay . ' Tháng ' . $thang . ', ' . $nam . ' lúc ' . $gio . ':' . $phut;
    }

    public static function getImgUrl($image, $width = 0, $height = 0, $type = 'resize')
    {
        if (empty($image)) {
            return "";
        }
        $rep = 'thumbs/' . $width . 'x' . $height . '_';
        $arrfile = explode('/', trim($image, '/'));
        $position = count($arrfile) - 1;
        $arrfile[$position] = $rep . $arrfile[$position];
        return url(implode('/', $arrfile));
    }

    public static function getImgUrlv2($image, $width = 0, $height = 0)
    {
        if (empty($image)) {
            return "";
        }
        $rep = $width . 'x' . $height . '_';
        $arrfile = explode('/', trim($image, '/'));
        $position = count($arrfile) - 1;
        $arrfile[$position] = $rep . $arrfile[$position];
        return url(implode('/', $arrfile));
    }

    public static function buttonShareFb($url)
    {
        if (empty($url)) {
            return "";
        }
        return '<a rel="nofollow" href="https://www.facebook.com/sharer.php?u=' . urlencode($url) . '" target="_blank" onclick="return !window.open(this.href, \'Facebook\', \'width=640,height=400\')" title="Chia sẻ bài viết"><img src="' . asset('static/frontend/images/icons/icon-02.svg') . '"></a>';
    }

    public static function buttonShareFbv2($url)
    {
        if (empty($url)) {
            return "";
        }
        return '<a rel="nofollow" href="https://www.facebook.com/sharer.php?u=' . urlencode($url) . '" target="_blank" onclick="return !window.open(this.href, \'Facebook\', \'width=640,height=400\')" title="Chia sẻ bài viết"><i class="tv-icon tv-share"></i></a>';
    }

    public static function secondsToMinutes($seconds)
    {
        $mins = floor($seconds / 60);
        $secs = $seconds % 60;

        return $mins . ':' . $secs;
    }

    public static function secondsToMinutesv2($seconds)
    {
        $mins = floor($seconds / 60);
        return $mins;
    }
}
