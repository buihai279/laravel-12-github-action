<?php

namespace App\Listeners;

use App\Events\ReplyComment;
use App\Model\Comment;
use App\Model\Notification;
use App\Model\Post;

class HandleReplyComment
{
    public function __construct()
    {

    }

    public function handle(ReplyComment $event)
    {
        $params = $event->params;
        $created_by_id = $params['created_by_id'];
        $post_id = $params['post_id'];
        $post = Post::find($post_id);
        $parent_id = $params['parent_id'];
        $parentComment = Comment::find($parent_id);
        $notification = Notification::where(['group_by_id' => $parent_id, 'type' => 'ReplyComment'])->first();
        if (empty($notification)) {
            Notification::create([
                'url' => $post->slug,
                'type' => 'ReplyComment',
                'user_id' => $parentComment->created_by_id,
                'group_by_id' => $parent_id,
                'created_by_ids' => serialize([$created_by_id]),
                'object_ids' => serialize([$post_id]),
                'content' => "@ đã trả lời bạn trong bài @",
                'changed_at' => now()
            ]);
        } else {
            $created_by_ids = Comment::where('parent_id', $parent_id)->orderBy('id', 'desc')->pluck('created_by_id')->toArray();
            $checkForRead = in_array($created_by_id, $created_by_ids);
            $notification->update([
                'created_by_ids' => serialize($created_by_ids),
                'changed_at' => now()
            ]);
            if ($checkForRead) {
                $notification->update([
                    'is_read' => false
                ]);
            }
        }
    }
}
