<?php

namespace App\Listeners;

use App\Events\LikeComment;
use App\Model\Comment;
use App\Model\Notification;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Support\Facades\DB;

class HandleLikeComment implements ShouldQueue
{
    public function __construct()
    {

    }

    public function handle(LikeComment $event)
    {
        $params = $event->params;
        $comment_id = $params['comment_id'];
        $created_by_id = $params['created_by_id'];
        $comment = Comment::find($comment_id);
        $post = $comment->post;
        $post_id = $post->id;
        $notification = Notification::where(['group_by_id' => $comment_id, 'type' => 'LikeComment'])->first();
        if (empty($notification)) {
            Notification::create([
                'url' => $post->slug,
                'type' => 'LikeComment',
                'user_id' => $comment->created_by_id,
                'group_by_id' => $comment_id,
                'created_by_ids' => serialize([$created_by_id]),
                'object_ids' => serialize([$comment_id, $post_id]),
                'content' => "@ vote Hữu ích cho bình luận @ của bạn trong bài @",
                'changed_at' => now()
            ]);
        } else {
            $created_by_ids = DB::table('likes')->where('comment_id', $notification->group_by_id)->orderBy('created_at', 'desc')->pluck('created_by_id')->toArray();
            $checkForRead = in_array($created_by_id, $created_by_ids);
            $notification->update([
                'created_by_ids' => serialize($created_by_ids),
                'changed_at' => now()
            ]);
            if ($checkForRead) {
                $notification->update([
                    'is_read' => false
                ]);
            }
        }
    }
}
