<?php

namespace App\Http\Resources;

use Carbon\Carbon;
use Illuminate\Http\Resources\Json\JsonResource;

class Campaign extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param \Illuminate\Http\Request $request
     * @return array
     */
    public function toArray($request)
    {
        $data = [];
        $end_text = '';
        if ($this->end_date) {
            $diff_date = Carbon::parse($this->end_date)->diff(now())->format('%H:%I');
            $end_text = $diff_date;
        } elseif ($this->end_clicks) {
            $end_text = $this->clicks . '/' . $this->end_clicks;
        } elseif ($this->end_impressions) {
            $end_text = $this->impressions . '/' . $this->end_impressions;
        }
        if ($request->campaign_area === 'cms_list_campaign') {
            $data = [
                'id' => $this->id,
                'name' => $this->name,
                'clicks' => $this->clicks,
                'impressions' => $this->impressions,
                'end_text' => $end_text,
                'created_at' => $this->created_at->format('h:i:s d/m/Y')
            ];
        } elseif ($request->campaign_area === 'cms_detail_campaign') {
            $ran_time = Carbon::parse($this->start_date)->diff(now())->format('%H:%I');
            $data = [
                'id' => $this->id,
                'name' => $this->name,
                'clicks' => $this->clicks,
                'impressions' => $this->impressions,
                'status' => $this->status,
                'end_text' => $end_text,
                'ran_time' => $ran_time,
                'partner' => $this->partner()->with('contacts')->first(),
                'banners' => $this->banners,
                'created_by_user_name' => $this->created_by_user->name,
                'created_at' => $this->created_at->format('h:i:s d/m/Y')
            ];
        }

        return $data;
    }
}
