<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class Banner extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param \Illuminate\Http\Request $request
     * @return array
     */
    public function toArray($request)
    {
        $data = [];
        if ($request->banner_area === 'front') {
            $data = [
                'link' => $this->link,
                'type' => $this->type,
                'slot' => $this->slot,
                'image_url' => $this->image_url,
            ];
        } else if ($request->banner_area === 'cms_list') {
            $campaign = $this->campaign()->select('name', 'start_date', 'end_date', 'end_clicks', 'end_impressions', 'clicks', 'impressions')->first();
            $data = [
                'id' => $this->id,
                'type' => $this->type,
                'slot' => $this->slot,
                'campaign' => $campaign,
            ];
        } else if ($request->banner_area === 'front_list') {
            $data = [
                'id' => $this->id,
                'type' => $this->type,
                'slot' => $this->slot,
                'image_pc' => $this->image_pc,
                'image_mb' => $this->image_mb,
            ];
        }

        return $data;
    }
}
