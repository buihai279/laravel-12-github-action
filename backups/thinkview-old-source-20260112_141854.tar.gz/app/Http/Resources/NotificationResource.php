<?php

namespace App\Http\Resources;

use Carbon\Carbon;
use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Support\Str;

class NotificationResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param \Illuminate\Http\Request $request
     * @return array
     */
    public function toArray($request)
    {
        $data = [];
        if ($request->notification_area === 'front_all') {
            $content = $this->content;
            $users = unserialize($this->created_by_ids);
            //Users
            $counter = count($users);
            if ($counter) {
                $thumb = \App\User::find($users[0])->avatar;
            }
            if ($counter === 1) {
                $usersStr = \App\User::find($users[0])->name;
            } else if ($counter === 2) {
                $usersStr = \App\User::find($users[0])->name . ', ' . \App\User::find($users[1])->name;
            } else {
                $usersStr = \App\User::find($users[0])->name . ', ' . \App\User::find($users[1])->name . ' và ' . ($counter - 2) . ' người khác';
            }
//            $content = preg_replace('/@/', $usersStr, $content, 1);
            $object_ids = unserialize($this->object_ids);
            if ($this->type === 'LikeComment') {
                //Comment content
                $commentStr = Str::limit(\App\Model\Comment::find($object_ids[0])->content, 25);
//                $content = preg_replace('/@/', $commentStr, $content, 1);
                //Post title
                $postStr = Str::limit(\App\Model\Post::find($object_ids[1])->title, 25);
//                $content = preg_replace('/@/', $postStr, $content, 1);
            } elseif ($this->type === 'ReplyComment') {
                //Post title
                $postStr = Str::limit(\App\Model\Post::find($object_ids[0])->title, 25);
//                $content = preg_replace('/@/', $postStr, $content, 1);
            }
            $data = [
                'id' => $this->id,
                'url' => $this->url,
                'type' => $this->type,
                'content' => $content,
                'userStr' => $usersStr,
                'commentStr' => $commentStr ?? '',
                'postStr' => $postStr,
                'is_read' => $this->is_read,
                'changed_at' => Carbon::parse($this->changed_at)->diffForHumans(),
                'thumb' => $thumb,

            ];
        }
        return $data;
    }
}
