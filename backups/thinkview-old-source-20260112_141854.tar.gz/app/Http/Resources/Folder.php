<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Support\Facades\DB;

class Folder extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param \Illuminate\Http\Request $request
     * @return array
     */
    public function toArray($request)
    {
        $data = [];
        if ($request->folder_area === 'cms') {
            $data = [
                'id' => $this->id,
                'name' => $this->name,
                'parent_id' => $this->parent_id,
                'level' => $this->level,
                'slot' => $this->slot,
                'is_showed' => $this->is_showed,
            ];
        } elseif ($request->folder_area === 'cms_header') {
            $data = [
                'id' => $this->id,
                'name' => $this->name,
                'background' => $this->background
            ];
        } elseif ($request->folder_area === 'cms_post_add') {
            $parent = $this->parent;
            if(empty($parent)) {
                $parent_name = null;
            } else {
                $parent_name = $parent->name;
            }
            $data = [
                'id' => $this->id,
                'name' => $this->name,
                'parent_name' => $parent_name
            ];
        } elseif ($request->folder_area === 'front_header') {
            $children = $this->children()->where('is_showed', 1)->orderBy('slot', 'desc')->get();
            $children = self::collection($children);
            $data = [
                'id' => $this->id,
                'name' => $this->name,
                'slug' => $this->slug,
                'children' => $children
            ];
        } elseif ($request->folder_area === 'cms_build_for_folders') {
            $last_built_at = DB::table('build_for_folders')->where('folder_id', $this->id)->orderBy('id', 'desc')->first()->created_at->diffForHumans();

            $data = [
                'id' => $this->id,
                'name' => $this->name,
                'last_built_at' => $last_built_at,
            ];
        }

        return $data;
    }
}
