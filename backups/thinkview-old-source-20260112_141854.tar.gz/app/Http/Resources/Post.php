<?php

namespace App\Http\Resources;

use Carbon\Carbon;
use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Support\Facades\Cache;

class Post extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param \Illuminate\Http\Request $request
     * @return array
     */
    public function toArray($request)
    {
        $data = [];

        if ($request->post_area === 'cms_post_detail') {
            $data = [
                'id' => $this->id,
                'title' => $this->title,
                'description' => $this->description,
                'cover' => $this->cover,
                'thumbnail' => $this->thumbnail,
                'content' => $this->content,
                'set_on_id' => $this->set_on_id,
                'list_on_ids' => $this->list_on_folders()->pluck('id'),
                'published_at' => $this->published_at,
                'priority' => $this->priority,
                'keywords' => unserialize($this->keywords),
                'is_sponsored' => $this->is_sponsored ? 1 : 0,
                'status' => $this->status,
                'tags' => $this->tags()->select('id', 'name')->get(),
            ];
        } else if ($request->post_area === 'cms_post_list') {
            $created_user = $this->created_user()->select('id', 'name')->first();
            $id = $this->id;
            $viewsMonth = Cache::get("ga-$id-month") ?? 'N/A';
            $viewsAll = Cache::get("ga-$id-all") ?? 'N/A';
            $data = [
                'id' => $this->id,
                'title' => $this->title,
                'thumbnail' => $this->thumbnail,
                'set_on_id' => $this->set_on_folder()->select('name', 'id')->get(),
                'list_on_ids' => $this->list_on_folders()->select('name', 'id')->get(),
                'created_at' => $this->created_at->diffForHumans(),
                'created_user' => $created_user,
                'published_at' => Carbon::parse($this->published_at)->diffForHumans(),
                'status' => $this->status,
                'is_sponsored' => $this->is_sponsored ? 1 : 0,
                'viewMonth' => $viewsMonth,
                'viewsAll' => $viewsAll
            ];
        } else if ($request->post_area === 'cms_build') {
            $data = [
                'id' => $this->id,
                'title' => $this->title,
                'thumbnail' => $this->thumbnail,
            ];
        } else if ($request->post_area === 'front_home_build') {
            $data = [
                'id' => $this->id,
                'title' => $this->title,
                'commentCount' => $this->comments->count(),
                'publish_at' => Carbon::parse($this->published_at)->diffForHumans(),
                'slug' => $this->slug,
                'thumbnail' => $this->thumbnail,
            ];
        } else if ($request->post_area === 'front_home_build_new') {
            $data = [
                'id' => $this->id,
                'title' => $this->title,
                'description' => $this->description,
                'commentCount' => $this->comments->count(),
                'publish_at' => Carbon::parse($this->published_at)->diffForHumans(),
                'slug' => $this->slug,
                'thumbnail' => $this->thumbnail,
            ];
        } else if ($request->post_area === 'front_detail') {
            $set_on_folder = $this->set_on_folder()->select('name', 'slug', 'id', 'parent_id')->first();
            if (!empty($set_on_folder->parent)) {
                $parent = $set_on_folder->parent()->select('name', 'slug', 'id')->first();
                unset($set_on_folder->parent);
                $set_on_folder->parent = $parent;
            }
            unset($set_on_folder->parent_id);
            $data = [
                'id' => $this->id,
                'title' => $this->title,
                'description' => $this->description,
                'thumbnail' => $this->thumbnail,
                'content' => $this->content,
                'commentCount' => $this->comments->count(),
                'publish_at' => Carbon::parse($this->published_at)->diffForHumans(),
                'slug' => $this->slug,
                'created_user' => $this->created_user()->select('id', 'name')->first(),
                'is_sponsored' => $this->is_sponsored,
                'tags' => $this->tags()->select('name', 'slug')->get(),
                'cover' => $this->cover,
                'updated_at' => $this->updated_at->diffForHumans(),
                'set_on_folder' => $set_on_folder,
                'keywords' => unserialize($this->keywords)
            ];
        }

        return $data;
    }
}
