<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class User extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param \Illuminate\Http\Request $request
     * @return array
     */
    public function toArray($request)
    {
        $data = [];
        if ($request->user_area === 'cms_auth_user') {
            $data = [
                'id' => $this->id,
                'name' => $this->name,
                'email' => $this->name,
                'avatar' => $this->avatar,
                'permissions' => $this->role->permissions(),
            ];
        } elseif ($request->user_area === 'cms_list_users') {
            $data = [
                'id' => $this->id,
                'name' => $this->name,
                'email' => $this->email,
                'avatar' => $this->avatar,
                'role' => $this->role()->select('id', 'name')->first(),
            ];
        } elseif ($request->user_area === 'front_my_account') {
            $data = [
                'id' => $this->id,
                'name' => $this->name,
                'email' => $this->email,
                'avatar' => $this->avatar,
                'login_by' => $this->login_by,
                'created_at' => $this->created_at->format('d/m/Y'),
                'front_info_updated_at' => $this->front_info_updated_at,
            ];
        }

        return $data;
    }
}
