<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class Comment extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param \Illuminate\Http\Request $request
     * @return array
     */
    public function toArray($request)
    {
        $data = [];
        $created_user = $this->created_user()->select('name', 'id', 'avatar')->first();
        $created_user = [
            'name' => $created_user->name,
            'id' => $created_user->id,
            'avatar' => $created_user->avatar,
        ];
        if ($request->comment_area === 'front_parent') {
            $data = [
                'id' => $this->id,
                'content' => nl2br($this->content),
                'created_user' => $created_user,
                'created_at' => $this->created_at->diffForHumans(),
                'number_children' => $this->child_comments()->count(),
                'number_likes' => $this->liked_users()->count(),
            ];
        } else if ($request->comment_area === 'front_child') {
            $data = [
                'id' => $this->id,
                'content' => nl2br($this->content),
                'created_user' => $created_user,
                'created_at' => $this->created_at->diffForHumans(),
                'number_likes' => $this->liked_users()->count(),
            ];
        }

        return $data;
    }
}
