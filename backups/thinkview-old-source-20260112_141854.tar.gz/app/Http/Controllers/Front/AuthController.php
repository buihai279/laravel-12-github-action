<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use App\Http\Resources\User as UserResource;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

class AuthController extends Controller
{
    public function login(Request $request)
    {
        $validation = Validator::make(
            $request->all(),
            [
                'email' => 'required|email',
                'login_by' => 'required'
            ]
        );
        if ($validation->fails()) {
            return $this->response422($validation->errors());
        }
        $user = User::where('email', $request->email)->first();

        if (empty($user)) {
            $params = $request->all();
            $params['role_id'] = 4;
            $user = User::create($params);
        } else {
            $user->update([
                'login_by' => $request->login_by,
            ]);
        }
        $token = $user->createToken('cms')->plainTextToken;
        $request->user_area = 'front_my_account';
        return $this->response200([
            'user' => new UserResource($user),
            'token' => $token
        ]);
    }

    public function loginApple(Request $request)
    {
        return $this->response200('OK!');
    }

    public function logout(Request $request)
    {
        $request->user()->tokens()->delete();

        return $this->response200('OK!');
    }

    public function user(Request $request)
    {
        $user = $request->user();
        $request->user_area = 'front_my_account';

        return new UserResource($user);
    }

    public function changePassword(Request $request)
    {
        $validation = Validator::make(
            $request->all(),
            [
                'old_password' => ['required', function ($attribute, $value, $fail) use ($request) {
                    if (!Hash::check($value, $request->user()->password)) {
                        return $fail('Mật khẩu không đúng!');
                    }
                }],
                'new_password' => 'required|string|min:6',
            ],
            [
                'new_password.required' => 'Password không được để trống!',
                'new_password.min' => 'Password tối thiểu :min kí tự!',
            ]
        );
        if ($validation->fails()) {
            return $this->response422($validation->errors());
        }
        $user = $request->user();
        $user->update([
            'password' => bcrypt($request->new_password),
        ]);

        return $this->response200("OK!");
    }

    public function changeInfo(Request $request)
    {
        $validation = Validator::make(
            $request->all(),
            [
                'avatar' => 'required',
                'name' => 'required',
            ]
        );
        if ($validation->fails()) {
            return $this->response422($validation->errors());
        }
        $user = $request->user();
        $user->update([
            'avatar' => $request->avatar,
            'name' => $request->name,
            'front_info_updated_at' => now()
        ]);

        return $this->response200("OK!");
    }
}
