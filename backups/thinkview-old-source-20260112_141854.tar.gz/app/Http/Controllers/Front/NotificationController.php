<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use App\Http\Resources\NotificationResource;
use App\Model\Notification;
use Illuminate\Http\Request;

class NotificationController extends Controller
{
    public function all(Request $request)
    {
        $user_id = $request->user()->id;
        $notifications = Notification::where('user_id', $user_id)->where('created_by_ids', '!=', 'a:0:{}')->orderBy('changed_at', 'desc')->paginate(10);
        $request->notification_area = 'front_all';

        return NotificationResource::collection($notifications);
    }

    public function read($notification_id)
    {
        if (!isset($notification_id) || empty($notification_id)) return $this->response422('Oops!');
        $notification = Notification::find($notification_id);
        if (empty($notification)) return $this->response422('Oops!');
        $notification->update(['is_read' => true]);

        return $this->response200($notification->id);
    }

    public function unseenCount(Request $request)
    {
        $user_id = $request->user()->id;
        $unseenCount = Notification::where('user_id', $user_id)->where('created_by_ids', '!=', 'a:0:{}')->where('is_read', 0)->count();

        return $this->response200($unseenCount);
    }
}
