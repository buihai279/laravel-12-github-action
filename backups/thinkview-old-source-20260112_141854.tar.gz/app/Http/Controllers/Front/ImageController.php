<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use Intervention\Image\Facades\Image;

class ImageController extends Controller
{
    public function upload(Request $request)
    {
        $validation = Validator::make(
            $request->all(),
            [
                'upload' => ['required', 'array'],
                'upload.*' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048'
            ]
        );
        if ($validation->fails()) {
            return $this->response422($validation->errors());
        }
        $t = Carbon::now();
        $day = $t->day;
        $month = $t->month;
        $year = $t->year;
        $upload = $request->file('upload');
        if (is_array($upload)) {
            $files = [];

            foreach ($upload as $file) {
                $dir = 'uploads/frontend/' . $year . '/' . $month . '/' . $day . '/';
                $filename = $file->getClientOriginalName();
                $arrFileName = explode('.', $filename);
                $arrFileName[0] = Str::slug($arrFileName[0]);
                $filename = implode('.', $arrFileName);
                $file->move($dir, $filename);
                $path = $dir . $filename;
                $files[] = $path;
            }

            return $this->response200($files);
        }
        $filename = $upload->getClientOriginalName();
        $arrFileName = explode('.', $filename);
        $arrFileName[0] = Str::slug($arrFileName[0]);
        $filename = implode('.', $arrFileName);
        $path = 'uploads/frontend/' . $year . '/' . $month . '/' . $day . '/' . $filename;
        $upload->move('uploads/frontend/' . $year . '/' . $month . '/' . $day, $filename);

        return $path;
    }

    public function delete(Request $request)
    {
        $validation = Validator::make(
            $request->all(),
            [
                'files' => 'required',
            ]
        );
        if ($validation->fails()) {
            return $this->response422($validation->errors());
        }
        $files = $request->files;
        foreach ($files as $file) {
            File::delete($file);
        }

        return $this->response200('OK!');
    }

    public function uploadEditor(Request $request)
    {
        $validation = Validator::make(
            $request->all(),
            [
                'file' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            ]
        );
        if ($validation->fails()) {
            return $this->response422($validation->errors());
        }
        $upload = $request->file('file');
        $filename = $upload->getClientOriginalName();
        $arrFileName = explode('.', $filename);
        $arrFileName[0] = Str::slug($arrFileName[0]);
        $arrFileName[1] = 'jpg';
        $filename = implode('.', $arrFileName);
        $path = 'uploads/editor/' . $filename;
        $upload->move('uploads/editor', $filename);
        $intervention = Image::make(public_path($path));
        $intervention->encode('jpg', 100)->save($path);

        return $this->response200(['link' => url($path)]);
    }

    public function listEditorImages()
    {
        $path = public_path('uploads/editor');
        $files = File::allFiles($path);
        $results = collect([]);
        foreach ($files as $file) {
            $fileName = $file->getFilename();
            if (!preg_match('/(-horizontal)|(-vertical)/i', $fileName)) {
                $results->push(['url' => url('uploads/editor/' . $fileName), 'time' => $file->getMTime()]);
            }
        }
        $results = $results->sortByDesc('time');
        $return = [];
        foreach ($results as $result) {
            $return[] = ['url' => $result['url']];
        }
        return $this->response200($return);
    }

    public function deleteEditorImage(Request $request)
    {
        $src = $request->src;
        $realSrc = parse_url($src)['path'];

        File::delete(public_path($realSrc));

        return $this->response200('OK!');
    }
}
