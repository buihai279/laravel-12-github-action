<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use App\Http\Resources\User;
use App\Model\Post;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class UserController extends Controller
{
    public function myAccountInfo(Request $request)
    {
        $user = $request->user();
        $request->user_area = 'front_my_account';
        return new User($user);
    }

    public function myAccountSeenPosts(Request $request)
    {
        $user = $request->user();
        $posts = Post::join('user_seen_posts', 'posts.id', 'user_seen_posts.post_id')->where('user_id', $user->id)->orderBy('user_seen_posts.created_at', 'desc')->paginate(9);
        $request->post_area = 'front_home_build_new';
        return \App\Http\Resources\Post::collection($posts);
    }

    public function seenPost($post_id, Request $request)
    {
        if (!isset($post_id) || empty($post_id)) return $this->response422('Oops!');
        $post = Post::where('status', 2)->where('published_at', '<=', now())->where('id', $post_id)->first();
        if (empty($post)) return $this->response422('Oops!');
        $check = DB::table('user_seen_posts')->where('user_id', $request->user()->id)->where(['post_id' => $post_id]);
        if (empty($check->first())) {
            DB::table('user_seen_posts')->insert(['user_id' => $request->user()->id, 'post_id' => $post_id, 'created_at' => now(), 'updated_at' => now()]);
        } else {
            $check->update(['created_at' => now(), 'updated_at' => now()]);
        }

        return $this->response200('OK!');
    }

    public function detail($user_id, Request $request) {
        if(!isset($user_id) || empty($user_id)) return $this->response422('Oops!');
        $user = \App\User::find($user_id);
        if(empty($user)) return $this->response422('Oops!');
        $request->user_area = 'front_my_account';
        return new User($user);
    }
}
