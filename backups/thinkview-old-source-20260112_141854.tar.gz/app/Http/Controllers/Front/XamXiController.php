<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use App\Model\Folder;
use App\Model\Post;
use Illuminate\Http\Request;

class XamXiController extends Controller
{
    public function checkObjectType(Request $request)
    {
        $objectSlug = $request->objectSlug;

        $objectId = 0;
        $type = 0;
        $flag = true;
        if (isset($objectSlug) && !empty($objectSlug)) {
            $arr = explode('-', explode('.', $objectSlug)[0]);
            $len = count($arr);
            $id = $arr[$len - 1];
            if (!isset($id) || empty($id)) {
                $flag = false;
            } else {
                $post = Post::where('id', $id)->first();
                if (empty($post)) {
                    $flag = false;
                } else {
                    $objectId = $post->id;
                    $type = 1;
                }
            }
        }
        if (!$flag) {
            $folder = Folder::where('slug', $objectSlug)->first();
            if (!empty($folder)) {
                $objectId = $folder->id;
                $type = 2;
            }
        }
        $result = ['object_id' => $objectId, 'type' => $type];
        return $this->response200($result);
    }
}
