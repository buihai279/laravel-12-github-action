<?php

namespace App\Http\Controllers\Front;


use App\Http\Controllers\Controller;
use App\Http\Resources\Campaign as CampaignResource;
use App\Http\Resources\Post as PostResource;
use App\Jobs\Campaign\ClickMB;
use App\Jobs\Campaign\ClickPC;
use App\Jobs\Campaign\ImpressMB;
use App\Jobs\Campaign\ImpressPC;
use App\Jobs\PR\CampaignsToPost;
use App\Jobs\PR\PostsToCampaign;
use App\Model\Banner;
use App\Model\Campaign;
use App\Model\Partner;
use App\Model\Post;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class CampaignController extends Controller
{
    public function listBanners(Request $request)
    {
        $banners = Banner::whereHas('campaign', function ($q) {
            $q->where('start_date', '<=', now())->where(function ($qq) {
                $qq->where('end_date', '>=', now())->orWhere('end_impressions', '>', 'impressions')->orWhere('end_clicks', '>', 'clicks');
            });
        });

        $banners = $banners->orderBy('type')->get();
        $request->banner_area = 'front_list';

        return \App\Http\Resources\Banner::collection($banners);
    }

    public function clickPC(Request $request)
    {
        $validation = Validator::make(
            $request->all(),
            [
                'banner_id' => 'required',
            ]
        );
        if ($validation->fails()) {
            return $this->response422($validation->errors());
        }
        $params = $request->all();
        ClickPC::dispatch($params);

        return $this->response200('OK!');
    }

    public function clickMB(Request $request)
    {
        $validation = Validator::make(
            $request->all(),
            [
                'banner_id' => 'required',
            ]
        );
        if ($validation->fails()) {
            return $this->response422($validation->errors());
        }
        $params = $request->all();
        ClickMB::dispatch($params);

        return $this->response200('OK!');
    }

    public function impressPC(Request $request)
    {
        $validation = Validator::make(
            $request->all(),
            [
                'banner_id' => 'required',
            ]
        );
        if ($validation->fails()) {
            return $this->response422($validation->errors());
        }
        $params = $request->all();
        ImpressPC::dispatch($params);

        return $this->response200('OK!');
    }

    public function impressMB(Request $request)
    {
        $validation = Validator::make(
            $request->all(),
            [
                'banner_id' => 'required',
            ]
        );
        if ($validation->fails()) {
            return $this->response422($validation->errors());
        }
        $params = $request->all();
        ImpressMB::dispatch($params);

        return $this->response200('OK!');
    }
}
