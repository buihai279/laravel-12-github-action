<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use App\Http\Resources\Post as PostResource;
use App\Model\Banner;
use App\Model\Folder;
use App\Model\Post;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;

class HomeController extends Controller
{
    public function toppingPosts(Request $request)
    {
        $tops = Post::join('build_tops_posts', 'posts.id', 'build_tops_posts.post_id')->where('status', 2)->where('published_at', '<=', now())->orderBy('build_tops_posts.created_at', 'asc')->get();
        $toAddTops = 2 - $tops->count();
        if ($toAddTops > 0) {
            $addTops = Post::where('status', 2)->where('published_at', '<=', now())->orderBy(DB::raw("DATE(published_at)"), 'desc')->orderBy('priority', 'desc')->orderBy(DB::raw("DATE_FORMAT(published_at, '%H:%i:%s')"), 'desc')->take($toAddTops)->get();
            $tops = $tops->merge($addTops);
        }
        $hots = Post::join('build_hots_posts', 'posts.id', 'build_hots_posts.post_id')->where('status', 2)->where('published_at', '<=', now())->orderBy('build_hots_posts.created_at', 'asc')->get();
        $toAddHots = 4 - $hots->count();
        if ($toAddHots > 0) {
            $addHots = Post::where('status', 2)->where('published_at', '<=', now())->orderBy(DB::raw("DATE(published_at)"), 'desc')->orderBy('priority', 'desc')->orderBy(DB::raw("DATE_FORMAT(published_at, '%H:%i:%s')"), 'desc')->take($toAddHots)->get();
            $hots = $hots->merge($addHots);
        }
        $trends = Post::join('build_trends_posts', 'posts.id', 'build_trends_posts.post_id')->orderBy('build_trends_posts.created_at', 'asc')->get();
        $toAddTrends = 3 - $trends->count();
        if ($toAddTrends > 0) {
            $addTrends = Post::where('status', 2)->where('published_at', '<=', now())->orderBy(DB::raw("DATE(published_at)"), 'desc')->orderBy('priority', 'desc')->orderBy(DB::raw("DATE_FORMAT(published_at, '%H:%i:%s')"), 'desc')->take($toAddTrends)->get();
            $trends = $trends->merge($addTrends);
        }
        $request->post_area = 'front_home_build';

        return $this->response200([
            'top' => PostResource::collection($tops),
            'hot' => PostResource::collection($hots),
            'trend' => PostResource::collection($trends),
        ]);
    }

    public function newPosts(Request $request)
    {
        $notInIds = $request->notInIds;

        $posts = Post::where('status', 2)->where('published_at', '<=', now())->whereNotIn('id', $notInIds)->orderBy(DB::raw("DATE(published_at)"), 'desc')->orderBy('priority', 'desc')->orderBy(DB::raw("DATE_FORMAT(published_at, '%H:%i:%s')"), 'desc')->paginate(8);
        $request->post_area = 'front_home_build_new';
        return PostResource::collection($posts);
    }

    public function getFirstTopFolders(Request $request)
    {
        $request->post_area = 'front_home_build';
        $fPosts = [];
        $sPosts = [];
        $first = Folder::where('is_showed', 1)->where('slot','!=', 0)->where('level', 1)->orderBy('slot')->first();
        if (!empty($first)) {
            $fPostsLen = $first->buildPosts()->count();
            $remains = 5 - $fPostsLen;
            $fPosts = Post::join('build_for_folders', 'posts.id', 'build_for_folders.post_id')->where('status', 2)->where('published_at', '<=', now())->where('folder_id', $first->id)->orderBy('build_for_folders.created_at', 'asc')->get();
            if ($remains > 0) {
                $fPosts = $fPosts->merge(Post::where('status', 2)->where('published_at', '<=', now())->orderBy(DB::raw("DATE(published_at)"), 'desc')->where('set_on_id', $first->id)->orderBy('priority', 'desc')->orderBy(DB::raw("DATE_FORMAT(published_at, '%H:%i:%s')"), 'desc')->take($remains)->get());
            }
            $fPosts = PostResource::collection($fPosts);
        }
        $second = Folder::where('is_showed', 1)->where('slot','!=', 0)->where('level', 1)->orderBy('slot')->skip(1)->first();
        if (!empty($second)) {
            $sPostsLen = $second->buildPosts()->count();
            $remains = 4 - $sPostsLen;
            $sPosts = Post::join('build_for_folders', 'posts.id', 'build_for_folders.post_id')->where('status', 2)->where('published_at', '<=', now())->where('folder_id', $second->id)->orderBy('build_for_folders.created_at', 'asc')->get();
            if ($remains > 0) {
                $sPosts = $sPosts->merge(Post::where('status', 2)->where('published_at', '<=', now())->orderBy(DB::raw("DATE(published_at)"), 'desc')->where('set_on_id', $second->id)->orderBy('priority', 'desc')->orderBy(DB::raw("DATE_FORMAT(published_at, '%H:%i:%s')"), 'desc')->take($remains)->get());
            }
            $sPosts = PostResource::collection($sPosts);
        }

        $results = ['fPosts' => $fPosts, 'sPosts' => $sPosts];

        return $this->response200($results);
    }

    public function getSecondTopFolders(Request $request)
    {
        $request->post_area = 'front_home_build';
        $fPosts = [];
        $sPosts = [];
        $first = Folder::where('is_showed', 1)->where('slot','!=', 0)->where('level', 1)->orderBy('slot')->skip(2)->first();
        if (!empty($first)) {
            $fPostsLen = $first->buildPosts()->count();
            $remains = 5 - $fPostsLen;
            $fPosts = Post::join('build_for_folders', 'posts.id', 'build_for_folders.post_id')->where('status', 2)->where('published_at', '<=', now())->where('folder_id', $first->id)->orderBy('build_for_folders.created_at', 'asc')->get();
            if ($remains > 0) {
                $fPosts = $fPosts->merge(Post::where('status', 2)->where('published_at', '<=', now())->orderBy(DB::raw("DATE(published_at)"), 'desc')->where('set_on_id', $first->id)->orderBy('priority', 'desc')->orderBy(DB::raw("DATE_FORMAT(published_at, '%H:%i:%s')"), 'desc')->take($remains)->get());
            }
            $fPosts = PostResource::collection($fPosts);
        }
        $second = Folder::where('is_showed', 1)->where('slot','!=', 0)->where('level', 1)->orderBy('slot')->skip(3)->first();
        if (!empty($second)) {
            $sPostsLen = $second->buildPosts()->count();
            $remains = 4 - $sPostsLen;
            $sPosts = Post::join('build_for_folders', 'posts.id', 'build_for_folders.post_id')->where('status', 2)->where('published_at', '<=', now())->where('folder_id', $second->id)->orderBy('build_for_folders.created_at', 'asc')->get();
            if ($remains) {
                $sPosts = $sPosts->merge(Post::where('status', 2)->where('published_at', '<=', now())->orderBy(DB::raw("DATE(published_at)"), 'desc')->where('set_on_id', $second->id)->orderBy('priority', 'desc')->orderBy(DB::raw("DATE_FORMAT(published_at, '%H:%i:%s')"), 'desc')->take($remains)->get());
            }
            $sPosts = PostResource::collection($sPosts);
        }

        $results = ['tPosts' => $fPosts, 'fPosts' => $sPosts];

        return $this->response200($results);
    }

    public function getBanners(Request $request)
    {
        $banners = Banner::where('apply_on', serialize([]))->orWhere('apply_on', serialize([0]))->get();

        return \App\Http\Resources\Banner::collection($banners);
    }

    public function listFoldersHeader(Request $request)
    {
        $folders = Folder::where('slot', '>', 0)->where('is_showed', 1)->where('level', 1)->orderBy('slot')->take(4)->get();

        $request->folder_area = 'front_header';

        return \App\Http\Resources\Folder::collection($folders);
    }

    public function getVideos()
    {
        if (Cache::has('videos')) {
            return Cache::get('videos');
        } else {
            $response = Http::get('https://www.googleapis.com/youtube/v3/search?part=snippet&channelId=UCMRCjWYwR5p2Plp_0ehIG6g&maxResults=4&order=date&type=video&key=AIzaSyAJIl3vdZi_KNY9Kq_XMrlrmKn29Cz0v2Q');
            $videos = $response->json();
            $videos = $videos['items']??[];
            $videos = array_map(function ($e) {
                return [
                    'url' => 'https://www.youtube.com/watch?v=' . $e['id']['videoId'],
                    'title' => $e['snippet']['title'],
                    'thumbnails' => $e['snippet']['thumbnails']['high']['url'],
                ];
            }, $videos);
            Cache::put('videos', $videos, now()->addDay());

            return $videos;
        }
    }
}
