<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use App\Model\Banner;
use App\Model\Post;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class PostController extends Controller
{
    public function detail($post_id, Request $request)
    {
        if (!isset($post_id) || empty($post_id)) return $this->response422('Oops!');
        if ($request->has('preview')) {
            $post = Post::where('id', $post_id)->first();
            if (empty($post)) return $this->response422('Oops!');
            $request->post_area = 'front_detail';
            return new \App\Http\Resources\Post($post);
        }
        $post = Post::where('status', 2)->where('published_at', '<=', now())->where('id', $post_id)->first();
        if (empty($post)) return $this->response422('Oops!');
        $request->post_area = 'front_detail';
        return new \App\Http\Resources\Post($post);
    }

    public function banners($post_id, Request $request)
    {
        if (!isset($post_id) || empty($post_id)) return $this->response422('Oops!');
        $post = Post::where('status', 2)->where('published_at', '<=', now())->where('id', $post_id)->first();
        if (empty($post)) return $this->response422('Oops!');

        $banners = Banner::all();
        $results = [];
        foreach ($banners as $banner) {
            $applyOns = unserialize($banner->apply_on);
            if (count($applyOns) === 0) $results[] = $banner;
        }
        $results = collect($results);
        $request->banner_area = 'front';
        return \App\Http\Resources\Banner::collection($results);
    }

    public function related($post_id, Request $request)
    {
        if (!isset($post_id) || empty($post_id)) return $this->response422('Oops!');
        $post = Post::where('status', 2)->where('published_at', '<=', now())->where('id', $post_id)->first();
        if (empty($post)) return $this->response422('Oops!');
        $tags = $post->tags()->pluck('id')->toArray();
        $posts = Post::where('status', 2)->where('published_at', '<=', now())->where('id', '!=', $post_id)->whereHas('tags', function ($q) use ($tags) {
            $q->whereIn('id', $tags);
        })->orderBy(DB::raw("DATE(published_at)"), 'desc')->orderBy('priority', 'desc')->orderBy(DB::raw("DATE_FORMAT(published_at, '%H:%i:%s')"), 'desc')->take(6)->get();
        $request->post_area = 'front_home_build';

        return \App\Http\Resources\Post::collection($posts);
    }

    public function recommended($post_id, Request $request)
    {
        if (!isset($post_id) || empty($post_id)) return $this->response422('Oops!');
        $post = Post::where('status', 2)->where('published_at', '<=', now())->where('id', $post_id)->first();
        if (empty($post)) return $this->response422('Oops!');
        $validation = Validator::make(
            $request->all(),
            [
                'excepted' => [function ($attribute, $value, $fail) use ($request) {
                    if (!is_array($value)) {
                        return $fail('Oops!');
                    }
                }],
            ]
        );
        if ($validation->fails()) {
            return $this->response422($validation->errors());
        }
        $excepted = $request->excepted;
        if(!isset($excepted) || empty($excepted)) $excepted = [];
        $posts = Post::where('status', 2)->where('published_at', '<=', now())->where('id', '!=', $post_id)->whereNotIn('id', $excepted)->orderBy(DB::raw("DATE(published_at)"), 'desc')->orderBy('priority', 'desc')->orderBy(DB::raw("DATE_FORMAT(published_at, '%H:%i:%s')"), 'desc')->paginate(9);
        $request->post_area = 'front_home_build_new';

        return \App\Http\Resources\Post::collection($posts);
    }
}
