<?php

namespace App\Http\Controllers\Front;

use App\Events\ReplyComment;
use App\Http\Controllers\Controller;
use App\Http\Resources\Comment as CommentResource;
use App\Jobs\Comment\Like;
use App\Model\Comment;
use App\Model\Post;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class CommentController extends Controller
{
    public function list($post_id, Request $request)
    {
        $post = Post::where('status', 2)->where('published_at', '<=', now())->where('id', $post_id)->first();
        if (empty($post)) {
            return $comments = collect([]);
        }
        $comments = $post->comments()->whereNull('parent_id')->with('liked_users');
        if ($request->has('sorted')) {
            $comments = $comments->leftJoin('likes', 'comments.id', 'likes.comment_id')->select('comments.*', DB::raw("COUNT(*) as 'number_likes'"))->groupBy('comments.id')->orderBy('number_likes', 'desc');
        }
        $comments = $comments->orderBy('id', 'desc')->paginate(5);
        $request->comment_area = 'front_parent';
        $comments = CommentResource::collection($comments);
        return $comments;
    }

    public function listChild($parent_id, Request $request)
    {
        $comment = Comment::where('id', $parent_id)->first();
        if (empty($comment)) {
            return $comments = collect([]);
        }
        $comments = $comment->child_comments()->paginate(10);
        $request->comment_area = 'front_child';
        $comments = CommentResource::collection($comments);
        return $comments;
    }

    public function add(Request $request)
    {
        $validation = Validator::make(
            $request->all(),
            [
                'post_id' => 'required',
                'content' => 'required|min:1',
            ],
            [
                'post_id' => 'Bài viết không được để trống!',
                'content.required' => 'Nội dung không được để trống!',
                'content.min' => 'Nội dung tối thiểu :min ký tự!',
            ]
        );
        if ($validation->fails()) {
            return $this->response422($validation->errors());
        }
        $p = Post::where('status', 2)->where('published_at', '<=', now())->where('id', $request->post_id)->first();
        if (empty($p)) {
            return $this->response422('Bài viết không tồn tại!');
        }
        $params = [
            'post_id' => $p->id,
            'content' => htmlspecialchars($request['content']),
            'parent_id' => $request->parent_id,
            'created_by_id' => auth()->user()->id
        ];
        $comment = Comment::create($params);
        if ($comment->parent_id) {
            $parentCreatedBy = Comment::find($comment->parent_id)->created_by_id;
            if ($parentCreatedBy !== $params['created_by_id']) {
                event(new ReplyComment($params));
            }
        }
        $request->comment_area = 'front_parent';

        return new CommentResource($comment);
    }

//    public function edit($id, Request $request)
//    {
//        $validation = Validator::make(
//            $request->all(),
//            [
//                'name' => 'required',
//            ],
//            [
//                'name.required' => 'Tên nhóm quyền không được để trống!',
//            ]
//        );
//        if ($validation->fails()) {
//            return $this->response422($validation->errors());
//        }
//        $role = Role::find($id);
//        if (empty($role)) {
//            return $this->response422("Không có role!");
//        }
//        $params = array_merge($request->only(['name', 'permissions']), ['id' => $id]);
//
//        Edit::dispatch($params);
//        return $this->response200("OK!");
//    }

    public function delete($comment_id, Request $request)
    {
        $comment = Comment::find($comment_id);
        if (empty($comment)) {
            return $this->response422("Không có comment!");
        }
        $params = ['id' => $comment_id];

        \App\Jobs\Comment\Delete::dispatch($params);
        return $this->response200("OK!");
    }

    public function like($comment_id)
    {
        Like::dispatch(['comment_id' => $comment_id, 'created_by_id' => auth()->user()->id]);

        return $this->response200("OK!");
    }

    public function checkLike(Request $request) {
        $validation = Validator::make(
            $request->all(),
            [
                'ids' => 'required'
            ],
        );
        if ($validation->fails()) {
            return $this->response422($validation->errors());
        }
        $ids = $request->ids;
        $user_id = $request->user()->id;
        $return = [];
        foreach ($ids as $id) {
            if(!empty(DB::table('likes')->where(['comment_id' => $id, 'created_by_id' => $user_id])->first())) {
                $return[$id] = true;
            } else {
                $return[$id] = false;
            }
        }

        return $return;
    }
}
