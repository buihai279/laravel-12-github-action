<?php

namespace App\Http\Controllers\Front;


use App\Http\Controllers\Controller;
use App\Http\Resources\Folder as FolderResource;
use App\Http\Resources\Post as PostResource;
use App\Jobs\Folder\Add;
use App\Jobs\Folder\ChangeBackground;
use App\Jobs\Folder\Edit;
use App\Jobs\Folder\Rearrange;
use App\Model\Banner;
use App\Model\Folder;
use App\Model\Post;
use App\Model\Tag;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class FolderController extends Controller
{
    public function topping($folder_id, Request $request)
    {
        if (!isset($folder_id) || empty($folder_id)) return $this->response422('Oops!');
        $folder = Folder::where('is_showed', 1)->where('id', $folder_id)->first();
        if (empty($folder)) return $this->response422('Oops!');

        if ($folder->level === 1) {
            $toAddTops = 2 - $folder->buildPosts()->count();
            $tops = Post::join('build_for_folders', 'posts.id', 'build_for_folders.post_id')->where('folder_id', $folder->id)->orderBy('build_for_folders.created_at', 'asc')->get();
            if ($toAddTops > 0) {
                $addTops = Post::where('set_on_id', $folder_id)->where('status', 2)->where('published_at', '<=', now())->orderBy(DB::raw("DATE(published_at)"), 'desc')->orderBy('priority', 'desc')->orderBy(DB::raw("DATE_FORMAT(published_at, '%H:%i:%s')"), 'desc')->take($toAddTops)->get();
                $tops = $tops->merge($addTops);
            }
            $request->post_area = 'front_home_build';
            $topping = [
                'name' => $folder->name,
                'children' => $folder->children()->where('is_showed', 1)->select('id', 'name', 'slug', 'background')->orderBy('slot')->get(),
                'posts' => PostResource::collection($tops)
            ];
        } else {
            $parent = $folder->parent;
            $topping = [
                'parent_name' => $parent->name,
                'parent_children' => $parent->children()->where('is_showed', 1)->select('id', 'name', 'slug', 'background')->orderBy('slot')->get(),
            ];
        }

        return $this->response200($topping);
    }

    public function banners($folder_id, Request $request)
    {
        if (!isset($folder_id) || empty($folder_id)) return $this->response422('Oops!');
        $folder = Folder::where('is_showed', 1)->where('id', $folder_id)->first();
        if (empty($folder)) return $this->response422('Oops!');
        $banners = Banner::all();
        $results = [];
        foreach ($banners as $banner) {
            $applyOns = unserialize($banner->apply_on);
            if (in_array($folder_id, $applyOns) || count($applyOns) === 0) $results[] = $banner;
        }
        $results = collect($results);
        $request->banner_area = 'front';
        return \App\Http\Resources\Banner::collection($results);
    }

    public function posts($folder_id, Request $request)
    {
        if (!isset($folder_id) || empty($folder_id)) return $this->response422('Oops!');
        $folder = Folder::where('is_showed', 1)->where('id', $folder_id)->first();
        if (empty($folder)) return $this->response422('Oops!');
        $posts = $folder->setOnPosts()->where('status', 2)->where('published_at', '<=', now())->union($folder->listOnPosts()->where('status', 2)->where('published_at', '<=', now())->select('posts.*'))->orderBy(DB::raw("DATE(published_at)"), 'desc')->orderBy('priority', 'desc')->orderBy(DB::raw("DATE_FORMAT(published_at, '%H:%i:%s')"), 'desc')->paginate(8);
        $request->post_area = 'front_home_build_new';
        return PostResource::collection($posts);
    }

    public function list(Request $request)
    {
        $folders = Folder::all();
        $request->folder_area = 'cms';

        return FolderResource::collection($folders);
    }

    public function add(Request $request)
    {
        $validation = Validator::make(
            $request->all(),
            [
                'name' => 'required',
                'level' => 'required|integer'
            ],
            [
                'name.required' => 'Tên folder không được để trống!',
                'name.unique' => 'Tên folder đã tồn tại!',
                'level.required' => 'Level cho folder!',
            ]
        );
        if ($validation->fails()) {
            return $this->response422($validation->errors());
        }
        $params = array_merge($request->only(['name', 'parent_id', 'level']), ['created_by_id' => $request->user()->id, 'slot' => 0]);

        Add::dispatch($params);
        return $this->response200("OK!");
    }

    public function edit($id, Request $request)
    {
        $validation = Validator::make(
            $request->all(),
            [
                'name' => 'required',
            ],
            [
                'name.required' => 'Tên folder không được để trống!',
                'is_showed.boolean' => 'Có hoặc không thôi ạ!',
            ]
        );
        if ($validation->fails()) {
            return $this->response422($validation->errors());
        }
        $folder = Folder::find($id);
        if (empty($folder)) {
            return $this->response422("Không có folder!");
        }
        $params = array_merge($request->only(['name', 'is_showed']), ['id' => $id]);

        Edit::dispatch($params);
        return $this->response200("OK!");
    }

    public function rearrange(Request $request)
    {
        $validation = Validator::make(
            $request->all(),
            [
                'folders' => 'required',
            ],
            [
                'folders.required' => 'Danh sách folders ạ!',
            ]
        );
        if ($validation->fails()) {
            return $this->response422($validation->errors());
        }
        $params = array_merge($request->only(['folders']));

        Rearrange::dispatch($params);
        return $this->response200("OK!");
    }

    public function searchFoldersForHeader(Request $request)
    {
        $name = $request->name;
        $folders = Folder::where('name', 'like', '%' . $name . '%')->get();
        $request->folder_area = 'cms_header';

        return FolderResource::collection($folders);
    }

    public function getTopFoldersForHeader(Request $request)
    {
        $recent = Folder::orderBy('id', 'desc')->take(5)->get();
        $suggest = Folder::orderBy('background_changed_at', 'desc')->orderBy('id', 'desc')->take(5)->get();

        $request->folder_area = 'cms_header';
        return ['suggest' => FolderResource::collection($suggest), 'recent' => FolderResource::collection($recent)];
    }

    public function changeFolderHeader(Request $request)
    {
        $validation = Validator::make(
            $request->all(),
            [
                'id' => 'required',
                'background' => 'required',
            ],
            [
                'id' => 'Cập nhật gì ta!',
                'background' => 'Header không được bỏ trống!',
            ]
        );
        if ($validation->fails()) {
            return $this->response422($validation->errors());
        }
        $background = $request->background;
        $params = ['id' => $request->id, 'background' => $background];
        ChangeBackground::dispatch($params);

        return $this->response200('OK!');
    }

    public function tagBanners($tag_id, Request $request)
    {
        if (!isset($tag_id) || empty($tag_id)) return $this->response422('Oops!');
        $tag = Tag::find($tag_id);
        if (empty($tag)) return $this->response422('Oops!');

        $banners = Banner::all();
        $results = [];
        foreach ($banners as $banner) {
            $applyOns = unserialize($banner->apply_on);
            if (count($applyOns) === 0) $results[] = $banner;
        }
        $results = collect($results);
        $request->banner_area = 'front';
        return \App\Http\Resources\Banner::collection($results);
    }

    public function tagPosts($tag_slug, Request $request)
    {
        if (!isset($tag_slug) || empty($tag_slug)) return $this->response422('Oops!');
        $tag = Tag::where('slug', $tag_slug)->first();
        if (empty($tag)) return $this->response422('Oops!');
        $posts = $tag->posts()->where('status', 2)->where('published_at', '<=', now())->orderBy(DB::raw("DATE(published_at)"), 'desc')->orderBy('priority', 'desc')->orderBy(DB::raw("DATE_FORMAT(published_at, '%H:%i:%s')"), 'desc')->paginate(9);
        $request->post_area = 'front_home_build_new';

        return PostResource::collection($posts);
    }
}
