<?php

namespace App\Http\Controllers;

use Analytics;
use App\Jobs\Helper\UpdatePostViews;
use App\Model\Folder;
use App\Model\Post;
use App\Model\Tag;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Intervention\Image\Facades\Image;
use Spatie\Analytics\Period;


class HelperController extends Controller
{
    public function uploadEditorImages(Request $request)
    {
        $validation = Validator::make(
            $request->all(),
            [
                'upload' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            ]
        );
        if ($validation->fails()) {
            return $this->response422($validation->errors());
        }
        $t = Carbon::now();
        $day = $t->day;
        $month = $t->month;
        $year = $t->year;
        $file = $request->file('upload');
        $filename = uniqid() . rand(0, 999) . rand(0, 9999) . '.' . 'jpg';
        $path = 'backend/uploads/editor/' . $year . '/' . $month . '/' . $day . '/' . $filename;
        $file->move('backend/uploads/editor/' . $year . '/' . $month . '/' . $day, $filename);

        return response()->json(['url' => '/' . $path]);
    }

    public function removeSlashFromTagSlug()
    {
        $tags = Tag::all();
        foreach ($tags as $tag) {
            $slug = $tag->slug;
            $slug = str_replace('/', '', $slug);
            $tag->update(['slug' => $slug]);
        }
    }

    public function reResizePostThumb()
    {
        Post::chunk(50, function ($posts) {
            foreach ($posts as $post) {
                $path = $post->thumbnail;
                //Thumb ngang
                $this->generateThumb($path, 384, 230, 'horizontal');
            }
        });
    }

    public function generateThumb($path, $width, $height, $strAfter)
    {
        $pathArr = explode('/', $path);
        $pathArrLen = count($pathArr);
        $intervention = Image::make(public_path($path));
        $imgName = $pathArr[$pathArrLen - 1];
        $imgNameArr = explode('.', $imgName);
        $imgNameArr['0'] = $imgNameArr['0'] . '-' . $strAfter;
        $imgName = implode('.', $imgNameArr);
        $pathArr[$pathArrLen - 1] = $imgName;
        $path = implode('/', $pathArr);

        $intervention->fit($width, $height)->save($path);
    }

    public function changeImagesToHttps()
    {
        $posts = Post::where('content', 'like', '%http://api.thinkview.vn%')->get();

        foreach ($posts as $post) {
            $content = str_replace("http://api.thinkview.vn", "https://api.thinkview.vn", $post->content);
            $post->update(['content' => $content]);
        }
    }

    public function generateSitemap()
    {
        $sitemap = app()->make('sitemap');
        $sitemap->setCache('laravel.sitemap', 60);
        if (!$sitemap->isCached()) {
            // add item to the sitemap (url, date, priority, freq)
            $sitemap->add('https://thinkview.vn');
            Post::where('status', 2)->where('published_at', '<=', now())->chunk(100, function ($posts) use ($sitemap) {
                foreach ($posts as $post) {
                    $sitemap->add('https://thinkview.vn/' . $post->slug);
                }
            });
            Folder::where('is_showed', 1)->where('slot', '>', 0)->chunk(100, function ($folders) use ($sitemap) {
                foreach ($folders as $folder) {
                    $sitemap->add('https://thinkview.vn/' . $folder->slug);
                }
            });
            Tag::chunk(100, function ($tags) use ($sitemap) {
                foreach ($tags as $tag) {
                    $sitemap->add('https://thinkview.vn/tag/' . $tag->slug);
                }
            });
            $sitemap->add('https://thinkview.vn/ve-chung-toi');
            $sitemap->add('https://thinkview.vn/lien-he');
        }

        $sitemap->store('xml', 'sitemap');
        return response()->download(public_path('sitemap.xml'));
    }

    public function updatePostViews()
    {
        UpdatePostViews::dispatch();

        return $this->response200('OK!');
    }
}
