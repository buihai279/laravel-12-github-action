<?php

namespace App\Http\Controllers\CMS;

use App\Http\Controllers\Controller;
use App\Model\Banner;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class BannerController extends Controller
{
    public function list(Request $request)
    {
        $filter = $request['filter'];

        $banners = Banner::whereNotNull('image_url');
        if (isset($filter['type']) && !empty($filter['type'])) {
            $banners = $banners->whereIn('type', $filter['type']);
        }
        $banners = $banners->paginate(20);
        $request->banner_area = 'cms_list';
        return \App\Http\Resources\Banner::collection($banners);
    }

    public function add(Request $request)
    {
        $validation = Validator::make(
            $request->all(),
            [
                'image_url' => 'required',
                'type' => 'required',
                'link' => 'required',
                'slot' => 'required',
                'apply_on' => [function ($attribute, $value, $fail) use ($request) {
                    if (!is_array($value)) {
                        return $fail('Áp dụng sai!');
                    }
                }]
            ]
        );
        if ($validation->fails()) {
            return $this->response422($validation->errors());
        }
        $params = [
            'image_url' => $request->image_url,
            'type' => $request->type,
            'link' => $request->link,
            'slot' => $request->slot,
        ];

        $apply_on = $request->apply_on;
        if (isset($apply_on)) {
            $params['apply_on'] = serialize($apply_on);
        }
        $banner = Banner::create($params);

        return $this->response200($banner);
    }

    public function edit(Request $request)
    {
        $validation = Validator::make(
            $request->all(),
            [
                'id' => 'required',
                'image_url' => 'required',
                'type' => 'required',
                'link' => 'required',
                'slot' => 'required',
                'apply_on' => [function ($attribute, $value, $fail) use ($request) {
                    if (!is_array($value)) {
                        return $fail('Áp dụng sai!');
                    }
                }]
            ]
        );
        if ($validation->fails()) {
            return $this->response422($validation->errors());
        }
        $banner = Banner::find($request->id);
        if (empty($banner)) return $this->response422('Sai Id!');
        $params = [
            'image_url' => $request->image_url,
            'type' => $request->type,
            'link' => $request->link,
            'slot' => $request->slot,
        ];
        $apply_on = $request->apply_on;
        if (isset($apply_on)) {
            $params['apply_on'] = serialize($apply_on);
        }
        $banner->update($params);

        return $this->response200($banner);
    }

    public function delete(Request $request)
    {
        $validation = Validator::make(
            $request->all(),
            [
                'id' => 'required',
            ]
        );
        if ($validation->fails()) {
            return $this->response422($validation->errors());
        }
        $banner = Banner::find($request->id);
        if (empty($banner)) return $this->response422('Sai Id!');
        $banner->delete();

        return $this->response200('OK');
    }
}
