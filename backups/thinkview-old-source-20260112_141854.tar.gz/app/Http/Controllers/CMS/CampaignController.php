<?php

namespace App\Http\Controllers\CMS;

use App\Http\Controllers\Controller;
use App\Http\Resources\Campaign as CampaignResource;
use App\Http\Resources\Post as PostResource;
use App\Jobs\Campaign\ClickMB;
use App\Jobs\Campaign\ClickPC;
use App\Jobs\Campaign\ImpressMB;
use App\Jobs\Campaign\ImpressPC;
use App\Jobs\Partner\Add;
use App\Jobs\PR\CampaignsToPost;
use App\Jobs\PR\PostsToCampaign;
use App\Model\Banner;
use App\Model\Campaign;
use App\Model\Partner;
use App\Model\Post;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class CampaignController extends Controller
{
    public function all(Request $request)
    {
        $search = $request->search;
        $filter = $request->filter;
        $campaigns = Campaign::where('name', 'like', '%' . $search . '%');
        if (isset($filter['partner_id']) && !empty($filter['partner_id'])) {
            $campaigns = $campaigns->whereIn('partner_id', $filter['partner_id']);
        }
        if (isset($filter['fromDate']) && !empty($filter['fromDate'])) {
            $campaigns = $campaigns->where('created_at', '>=', $filter['fromDate']);
        }
        if (isset($filter['toDate']) && !empty($filter['toDate'])) {
            $campaigns = $campaigns->where('created_at', '<=', $filter['toDate']);
        }
        if (isset($filter['status']) && !empty($filter['status'])) {
            if ($filter['status'] === 1) $campaigns = $campaigns->where('start_date', '>', now());
            if ($filter['status'] === 2) $campaigns = $campaigns->where('start_date', '<=', now())->where(function ($q) {
                $q->where('end_date', '>=', now())->orWhere('end_impressions', '>', 'impressions')->orWhere('end_clicks', '>', 'clicks');
            });
            if ($filter['status'] === 3) $campaigns = $campaigns->where('start_date', '>', now())->where(function ($q) {
                $q->where('end_date', '<', now())->orWhere('end_impressions', '<=', 'impressions')->orWhere('end_clicks', '<=', 'clicks');
            });
        }
        $campaigns = $campaigns->orderBy('id', 'desc')->paginate(20);
        $request->campaign_area = 'cms_list_campaign';

        return CampaignResource::collection($campaigns);
    }

    public function detail($campaign_id, Request $request)
    {
        $campaign = Campaign::find($campaign_id);
        if (empty($campaign)) return $this->response422("Oops!");
        $request->campaign_area = 'cms_detail_campaign';

        return new CampaignResource($campaign);
    }

    public function add(Request $request)
    {
        $validation = Validator::make(
            $request->all(),
            [
                'name' => 'required',
                'partner_id' => 'required',
                'start_date' => 'required',
            ]
        );
        if ($validation->fails()) {
            return $this->response422($validation->errors());
        }

        $params = $request->only(['name', 'partner_id', 'start_date', 'end_date', 'end_clicks', 'end_impressions', 'banners']);
        $params['created_by_id'] = auth()->user()->id;
        \App\Jobs\Campaign\Add::dispatch($params);

        return $this->response200('OK!');
    }

    public function addPartner(Request $request)
    {
        $validation = Validator::make(
            $request->all(),
            [
                'name' => 'required',
            ]
        );
        if ($validation->fails()) {
            return $this->response422($validation->errors());
        }
        $params = ['name' => $request->name];
        $partner = Partner::create(['name' => $params['name']]);

        return $this->response200($partner);
    }

    public function addContact(Request $request)
    {
        $validation = Validator::make(
            $request->all(),
            [
                'partner_id' => 'required|integer',
            ]
        );
        if ($validation->fails()) {
            return $this->response422($validation->errors());
        }
        $params = $request->all();
        \App\Jobs\Contact\Add::dispatch($params);
        return $this->response200('OK!');
    }

    public function filterPartners(Request $request)
    {
        $search = $request->search;
        $campaigns = Partner::with('contacts')->where('name', 'like', '%' . $search . '%')->take(5)->get();

        return $this->response200($campaigns);
    }

    public function listPRPost(Request $request)
    {
        $search = $request->search;
        $posts = Post::where('title', 'like', '%' . $search . '%')->where('status', 2)->where('published_at', '<=', now())->where('is_sponsored', true)->orderBy('published_at', 'desc')->paginate(20);
        $request->post_area = 'cms_post_list';

        return PostResource::collection($posts);
    }

    public function addPRToCampaign(Request $request)
    {
        $validation = Validator::make(
            $request->all(),
            [
                'campaign_id' => 'required',
                'post_ids' => 'required',
            ]
        );
        if ($validation->fails()) {
            return $this->response422($validation->errors());
        }
        $params = ['post_ids' => $request->post_ids, 'campaign_id' => $request->campaign_id];
        PostsToCampaign::dispatch($params);

        return $this->response200('OK!');
    }

    public function addCampaignToPost(Request $request)
    {
        $validation = Validator::make(
            $request->all(),
            [
                'post_id' => 'required',
                'campaign_ids' => 'required',
            ]
        );
        if ($validation->fails()) {
            return $this->response422($validation->errors());
        }
        $params = ['post_id' => $request->post_id, 'campaign_ids' => $request->campaign_ids];
        CampaignsToPost::dispatch($params);

        return $this->response200('OK!');
    }

    public function listBanners(Request $request)
    {
        $filter = $request->filter;
        $banners = Banner::whereNotNull('id');
        if (isset($filter['fromDate']) && !empty($filter['fromDate'])) {
            $banners = $banners->whereHas('campaign', function ($q) use ($filter) {
                $q->where('start_date', '>=', $filter['fromDate']);
            });
        }
        if (isset($filter['toDate']) && !empty($filter['toDate'])) {
            $banners = $banners->whereHas('campaign', function ($q) use ($filter) {
                $q->where('start_date', '<=', $filter['toDate']);
            });
        }
        $banners = $banners->orderBy('id', 'desc')->get();
        $request->banner_area = 'cms_list';

        return \App\Http\Resources\Banner::collection($banners);
//        return Banner::with('campaigns')->orderBy('id', 'desc')->get();
    }

    public function filterCampaigns(Request $request)
    {
        $search = $request->search;
        $campaigns = Campaign::where('name', 'like', '%' . $search . '%')->orderBy('id', 'desc')->paginate(20);
        $request->campaign_area = 'cms_list_campaign';

        return CampaignResource::collection($campaigns);
    }

    public function addCampaign(Request $request)
    {
        $validation = Validator::make(
            $request->all(),
            [
                'name' => 'required',
                'end_type' => 'required',
                'partner_id' => 'required',
            ]
        );
        if ($validation->fails()) {
            return $this->response422($validation->errors());
        }

        $params = $request->all();
        $params['created_by_id'] = auth()->user()->id;
        \App\Jobs\Campaign\Add::dispatch($params);

        return $this->response200('OK!');
    }

    public function detailCampaign($campaign_id, Request $request)
    {
        $campaign = Campaign::find($campaign_id);
        if (empty($campaign)) return $this->response422("Không có campaign!");

        $request->campaign_area = 'cms_detail_campaign';

        return new CampaignResource($campaign);
    }

    public function clickPC(Request $request)
    {
        $validation = Validator::make(
            $request->all(),
            [
                'campaign_id' => 'required',
                'banner_id' => 'required',
            ]
        );
        if ($validation->fails()) {
            return $this->response422($validation->errors());
        }
        $params = $request->all();
        ClickPC::dispatch($params);

        return $this->response200('OK!');
    }

    public function clickMB(Request $request)
    {
        $validation = Validator::make(
            $request->all(),
            [
                'campaign_id' => 'required',
                'banner_id' => 'required',
            ]
        );
        if ($validation->fails()) {
            return $this->response422($validation->errors());
        }
        $params = $request->all();
        ClickMB::dispatch($params);

        return $this->response200('OK!');
    }

    public function impressPC(Request $request)
    {
        $validation = Validator::make(
            $request->all(),
            [
                'campaign_id' => 'required',
                'banner_id' => 'required',
            ]
        );
        if ($validation->fails()) {
            return $this->response422($validation->errors());
        }
        $params = $request->all();
        ImpressPC::dispatch($params);

        return $this->response200('OK!');
    }

    public function impressMB(Request $request)
    {
        $validation = Validator::make(
            $request->all(),
            [
                'campaign_id' => 'required',
                'banner_id' => 'required',
            ]
        );
        if ($validation->fails()) {
            return $this->response422($validation->errors());
        }
        $params = $request->all();
        ImpressMB::dispatch($params);

        return $this->response200('OK!');
    }
}
