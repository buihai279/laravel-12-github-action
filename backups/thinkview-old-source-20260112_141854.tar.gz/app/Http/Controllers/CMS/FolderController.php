<?php

namespace App\Http\Controllers\CMS;


use App\Http\Controllers\Controller;
use App\Http\Resources\Folder as FolderResource;
use App\Jobs\Folder\Add;
use App\Jobs\Folder\ChangeBackground;
use App\Jobs\Folder\Edit;
use App\Jobs\Folder\Rearrange;
use App\Model\Folder;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class FolderController extends Controller
{
    public function list(Request $request)
    {
        $folders = Folder::all();
        $request->folder_area = 'cms';

        return FolderResource::collection($folders);
    }

    public function add(Request $request)
    {
        $validation = Validator::make(
            $request->all(),
            [
                'name' => 'required',
                'level' => 'required|integer'
            ],
            [
                'name.required' => 'Tên folder không được để trống!',
                'name.unique' => 'Tên folder đã tồn tại!',
                'level.required' => 'Level cho folder!',
            ]
        );
        if ($validation->fails()) {
            return $this->response422($validation->errors());
        }
        $params = array_merge($request->only(['name', 'parent_id', 'level']), ['created_by_id' => $request->user()->id, 'slot' => 0]);

        Add::dispatch($params);
        return $this->response200("OK!");
    }

    public function edit($id, Request $request)
    {
        $validation = Validator::make(
            $request->all(),
            [
                'name' => 'required',
            ],
            [
                'name.required' => 'Tên folder không được để trống!',
                'is_showed.boolean' => 'Có hoặc không thôi ạ!',
            ]
        );
        if ($validation->fails()) {
            return $this->response422($validation->errors());
        }
        $folder = Folder::find($id);
        if (empty($folder)) {
            return $this->response422("Không có folder!");
        }
        $params = array_merge($request->only(['name', 'is_showed']), ['id' => $id]);

        Edit::dispatch($params);
        return $this->response200("OK!");
    }

    public function rearrange(Request $request)
    {
        $validation = Validator::make(
            $request->all(),
            [
                'folders' => 'required',
            ],
            [
                'folders.required' => 'Danh sách folders ạ!',
            ]
        );
        if ($validation->fails()) {
            return $this->response422($validation->errors());
        }
        $params = array_merge($request->only(['folders']));

        Rearrange::dispatch($params);
        return $this->response200("OK!");
    }

    public function searchFoldersForHeader(Request $request)
    {
        $name = $request->name;
        $folders = Folder::where('name', 'like', '%' . $name . '%')->get();
        $request->folder_area = 'cms_header';

        return FolderResource::collection($folders);
    }

    public function getTopFoldersForHeader(Request $request)
    {
        $recent = Folder::orderBy('id', 'desc')->take(5)->get();
        $suggest = Folder::orderBy('background_changed_at', 'desc')->orderBy('id', 'desc')->take(5)->get();

        $request->folder_area = 'cms_header';
        return ['suggest' => FolderResource::collection($suggest), 'recent' => FolderResource::collection($recent)];
    }

    public function changeFolderHeader(Request $request)
    {
        $validation = Validator::make(
            $request->all(),
            [
                'id' => 'required',
                'background' => 'required',
            ],
            [
                'id' => 'Cập nhật gì ta!',
                'background' => 'Header không được bỏ trống!',
            ]
        );
        if ($validation->fails()) {
            return $this->response422($validation->errors());
        }
        $background = $request->background;
        $params = ['id' => $request->id, 'background' => $background];
        ChangeBackground::dispatch($params);

        return $this->response200('OK!');
    }
}
