<?php

namespace App\Http\Controllers\CMS;

use App\Http\Controllers\Controller;
use App\Http\Resources\Folder as FolderResource;
use App\Http\Resources\Post as PostResource;
use App\Jobs\Build\ChangeHot;
use App\Jobs\Build\ChangeTop;
use App\Jobs\Build\ChangeTrend;
use App\Jobs\Build\ForFolder;
use App\Model\Folder;
use App\Model\Post;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class BuildController extends Controller
{
    public function getTop(Request $request)
    {
        $posts = DB::table('posts')->join('build_tops_posts', 'posts.id', 'build_tops_posts.post_id')->orderBy('build_tops_posts.created_at', 'asc')->get();
        $request->post_area = 'cms_build';

        return PostResource::collection($posts);
    }

    public function getHot(Request $request)
    {
        $posts = DB::table('posts')->join('build_hots_posts', 'posts.id', 'build_hots_posts.post_id')->orderBy('build_hots_posts.created_at', 'asc')->get();
        $request->post_area = 'cms_build';

        return PostResource::collection($posts);
    }

    public function getTrend(Request $request)
    {
        $posts = DB::table('posts')->join('build_trends_posts', 'posts.id', 'build_trends_posts.post_id')->orderBy('build_trends_posts.created_at', 'asc')->get();
        $request->post_area = 'cms_build';

        return PostResource::collection($posts);
    }

    public function changeHot(Request $request)
    {
        $validation = Validator::make(
            $request->all(),
            [
                'post_ids' => ['required', function ($attribute, $value, $fail) use ($request) {
                    if (!is_array($value)) {
                        return $fail('Wrong input!');
                    }
                    if (count($value) > 4) {
                        return $fail('Tối đa 4 bài!');
                    }
                }],
            ]
        );
        if ($validation->fails()) {
            return $this->response422($validation->errors());
        }
        if (isset($request->post_ids) && !empty($request->post_ids)) {
            foreach ($request->post_ids as $post_id) {
                $p = Post::find($post_id);
                if (empty($p)) {
                    return $this->response422('Danh sách bài viết không hợp lệ');
                }
            }
            $params = $request->post_ids;;
        } else {
            $params = [];
        }

        ChangeHot::dispatch($params);
        return $this->response200("OK!");
    }

    public function changeTrend(Request $request)
    {
        $validation = Validator::make(
            $request->all(),
            [
                'post_ids' => ['required', function ($attribute, $value, $fail) use ($request) {
                    if (!is_array($value)) {
                        return $fail('Wrong input!');
                    }
                    if (count($value) > 4) {
                        return $fail('Tối đa 3 bài!');
                    }
                }],
            ]
        );
        if ($validation->fails()) {
            return $this->response422($validation->errors());
        }
        if (isset($request->post_ids) && !empty($request->post_ids)) {
            foreach ($request->post_ids as $post_id) {
                $p = Post::find($post_id);
                if (empty($p)) {
                    return $this->response422('Danh sách bài viết không hợp lệ');
                }
            }
            $params = $request->post_ids;
        } else {
            $params = [];
        }

        ChangeTrend::dispatch($params);
        return $this->response200("OK!");
    }

    public function changeTop(Request $request)
    {
        $validation = Validator::make(
            $request->all(),
            [
                'post_ids' => ['required', function ($attribute, $value, $fail) use ($request) {
                    if (!is_array($value)) {
                        return $fail('Wrong input!');
                    }
                    if (count($value) > 2) {
                        return $fail('Tối đa 2 bài!');
                    }
                }],
            ]
        );
        if ($validation->fails()) {
            return $this->response422($validation->errors());
        }
        if (isset($request->post_ids) && !empty($request->post_ids)) {
            foreach ($request->post_ids as $post_id) {
                $p = Post::find($post_id);
                if (empty($p)) {
                    return $this->response422('Danh sách bài viết không hợp lệ');
                }
            }
            $params = $request->post_ids;
        } else {
            $params = [];
        }

        ChangeTop::dispatch($params);
        return $this->response200("OK!");
    }

    public function searchPost(Request $request)
    {
        $search = $request->search;
        $folders = $request->folders;
        $posts = Post::where('title', 'like', '%' . $search . '%')->where('status', 2)->where('published_at', '<=', now());
        if (isset($folders) && !empty($folders)) {
            $posts = $posts->whereIn('set_on_id', $folders)->whereHas('list_on_folders', function ($qq) use ($folders) {
                $qq->orWhere('folder_id', $folders);
            });
        }
        $posts = $posts->orderBy('published_at', 'desc')->take(5)->get();
        $request->post_area = 'cms_build';
        return PostResource::collection($posts);
    }

    public function listFolders(Request $request)
    {
        $folders = Folder::where('is_showed', 1)->where('level', 1)->get();

        $request->folder_area = 'cms_post_add';
        return FolderResource::collection($folders);
    }

    public function buildForFolder(Request $request)
    {
        $validation = Validator::make(
            $request->all(),
            [
                'post_ids' => ['required', function ($attribute, $value, $fail) use ($request) {
                    if (!is_array($value)) {
                        return $fail('Wrong input!');
                    }
                    if (count($value) > 2) {
                        return $fail('Tối đa 2 bài!');
                    }
                }],
                'folder_id' => 'required'
            ]
        );
        if ($validation->fails()) {
            return $this->response422($validation->errors());
        }
        $folder_id = $request->folder_id;
        $folder = Folder::where('is_showed', 1)->where('level', 1)->where('id', $folder_id)->first();
        if (empty($folder)) return $this->response422('Folder không hợp lệ!');
        if (isset($request->post_ids) && !empty($request->post_ids)) {
            foreach ($request->post_ids as $post_id) {
                $p = Post::find($post_id);
                if (empty($p)) {
                    return $this->response422('Danh sách bài viết không hợp lệ');
                }
            }
            $params = ['post_ids' => $request->post_ids];
        } else {
            $params = ['post_ids' => []];
        }
        $params['folder_id'] = $folder_id;

        ForFolder::dispatch($params);
        return $this->response200("OK!");
    }

    public function getFolderPostsBuild(Request $request)
    {
        $validation = Validator::make(
            $request->all(),
            [
                'folder_id' => 'required'
            ]
        );
        if ($validation->fails()) {
            return $this->response422($validation->errors());
        }
        $folder_id = $request->folder_id;
        $folder = Folder::where('is_showed', 1)->where('level', 1)->where('id', $folder_id)->first();
        if (empty($folder)) return $this->response422('Folder không hợp lệ!');
        $posts = DB::table('posts')->join('build_for_folders', 'posts.id', 'build_for_folders.post_id')->where('folder_id', $folder_id)->orderBy('build_for_folders.created_at', 'asc')->get();
        $request->post_area = 'cms_build';
        return PostResource::collection($posts);
    }
}
