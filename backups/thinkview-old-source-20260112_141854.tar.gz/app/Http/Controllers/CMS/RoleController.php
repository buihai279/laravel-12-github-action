<?php

namespace App\Http\Controllers\CMS;

use App\Http\Controllers\Controller;
use App\Http\Resources\Role as RoleResource;
use App\Jobs\Role\Add;
use App\Jobs\Role\Delete;
use App\Jobs\Role\Edit;
use App\Model\Role;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class RoleController extends Controller
{
    public function list(Request $request)
    {
        $roles = Role::all();
        $request->role_area = 'cms';

        return RoleResource::collection($roles);
    }

    public function add(Request $request)
    {
        $validation = Validator::make(
            $request->all(),
            [
                'name' => 'required|unique:roles',
            ],
            [
                'name.required' => 'Tên nhóm quyền không được để trống!',
                'name.unique' => 'Nhóm quyền đã tồn tại!',
            ]
        );
        if ($validation->fails()) {
            return $this->response422($validation->errors());
        }
        $params = array_merge($request->only(['name', 'permissions']), ['created_by_id' => $request->user()->id]);

        Add::dispatch($params);
        return $this->response200("OK!");
    }

    public function edit($id, Request $request)
    {
        $validation = Validator::make(
            $request->all(),
            [
                'name' => 'required',
            ],
            [
                'name.required' => 'Tên nhóm quyền không được để trống!',
            ]
        );
        if ($validation->fails()) {
            return $this->response422($validation->errors());
        }
        $role = Role::find($id);
        if (empty($role)) {
            return $this->response422("Không có role!");
        }
        $params = array_merge($request->only(['name', 'permissions']), ['id' => $id]);

        Edit::dispatch($params);
        return $this->response200("OK!");
    }

    public function delete($id, Request $request)
    {
        $role = Role::find($id);
        if (empty($role)) {
            return $this->response422("Không có role!");
        }
        $params = ['id' => $id];

        Delete::dispatch($params);
        return $this->response200("OK!");
    }
}
