<?php

namespace App\Http\Controllers\CMS;

use App\Model\Post;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Str;
use Intervention\Image\Facades\Image;
use Illuminate\Support\Facades\File;
use App\Exports\PostsExport;
use App\Http\Controllers\Controller;
use App\Http\Resources\Folder as FolderResource;
use App\Http\Resources\Post as PostResource;
use App\Http\Resources\Tag as TagResource;
use App\Model\Folder;
use App\Model\Tag;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Maatwebsite\Excel\Facades\Excel;

class PostController extends Controller
{
    public function list(Request $request)
    {
        $user = $request->user();
        $search = $request->search;
        $filter = $request->filter;
        $sort = $request->sort;
        if ($user->can('posts.list_editor')) {
            $posts = Post::where(function ($q) use ($search) {
                $q->orWhere('title', 'like', '%' . $search . '%')->orWhere('description', 'like', '%' . $search . '%');
            });
        } elseif ($user->can('posts.list_writer')) {
            $posts = Post::where('created_by_id', $user->id)->where(function ($q) use ($search) {
                $q->orWhere('title', 'like', '%' . $search . '%')->orWhere('description', 'like', '%' . $search . '%');
            });
        }
        if (isset($filter['folder']) && !empty($filter['folder'])) {
            $posts = $posts->where(function ($q) use ($filter) {
                $q->whereHas('list_on_folders', function ($qq) use ($filter) {
                    $qq->whereIn('folder_id', $filter['folder']);
                })->orWhereIn('set_on_id', $filter['folder']);
            });
        }
        if (isset($filter['status']) && !empty($filter['status'])) {
            $posts = $posts->where(function ($q) use ($filter) {
                $q->orWhereIn('status', $filter['status']);
            });
        }
        if (isset($filter['is_sponsored']) && !empty($filter['is_sponsored'])) {
            if ($filter['is_sponsored'] === 1) $posts = $posts->where('is_sponsored', 1);
            elseif ($filter['is_sponsored'] === 0) $posts = $posts->where('is_sponsored', 0);
        }
        if (isset($filter['created_by_id']) && !empty($filter['created_by_id'])) {
            $posts->whereIn('created_by_id', $filter['created_by_id']);
        }
        if (isset($filter['from_date']) && !empty($filter['from_date']) && isset($filter['to_date']) && !empty($filter['to_date'])) {
            $from = new \DateTime($filter['from_date']);
            $to = (new \DateTime($filter['to_date']))->modify('+1 day');
            $posts = $posts->whereBetween('created_at', [$from, $to]);
        }
        if (isset($sort) && !empty($sort) && $sort == 2) {
            $posts = $posts->orderBy('id', 'asc');
        } else {
            $posts = $posts->orderBy('id', 'desc');
        }
        $posts = $posts->paginate(20);
        $request->post_area = 'cms_post_list';

        return PostResource::collection($posts);
    }

    public function exportExcel(Request $request)
    {
        $search = $request->search;
        $filter = $request->filter;
        $sort = $request->sort;
        $params = ['search' => $search, 'filter' => $filter, 'sort' => $sort];
        return Excel::download(new PostsExport($params), 'posts-views.xlsx');
    }

    public function addTag(Request $request)
    {
        $validation = Validator::make(
            $request->all(),
            [
                'name' => 'required|unique:tags'
            ],
            [
                'name.required' => 'Tên tag không được trống!',
                'name.unique' => 'Tag đã tồn tại!',
            ]
        );
        if ($validation->fails()) {
            return $this->response422($validation->errors());
        }
        $params = array_merge($request->only(['name']), ['created_by_id' => $request->user()->id]);

        $params['slug'] = Str::slug($params['name']);

        $tag = Tag::create($params);
        return $this->response200(['tag_id' => $tag->id]);
    }

    public function listTags(Request $request)
    {
        $search = $request->search;
        $tags = Tag::where('name', 'like', '%' . $search . '%')->take(50)->get();
        $request->tag_area = 'cms_list_tags';

        return TagResource::collection($tags);
    }

    public function add(Request $request)
    {
        $validation = Validator::make(
            $request->all(),
            [
                'title' => 'required',
                'description' => 'required',
                'content' => 'required',
                'set_on_id' => 'required',
                'list_on_ids' => [function ($attribute, $value, $fail) use ($request) {
                    if (in_array($request->set_on_id, $value)) {
                        return $fail('Không được list lên folder đã set!');
                    }
                }],
                'priority' => 'required',
                'action' => ['required', 'integer', 'min:0', 'max:2']
            ],
            [
                'title.required' => 'Tiêu đề không được để trống!',
                'description.required' => 'Mô tả không được để trống!',
                'content.required' => 'Nội dung không được để trống!',
                'set_on_id.required' => 'Set on không được để trống!',
                'priority.required' => 'Độ ưu tiên không được để trống!',
                'action' => 'Hành động không hợp lệ!'
            ]
        );
        if ($validation->fails()) {
            return $this->response422($validation->errors());
        }
        $setOnId = $request->set_on_id;
        $setOnFolder = Folder::find($setOnId);
        if (empty($setOnFolder)) return $this->response422('Set on sai!');
        $listOnIds = [];
        $reqLists = $request->list_on_ids;
        if (isset($reqLists) && !empty($reqLists)) {
            foreach ($request->list_on_ids as $listOnId) {
                if (!empty(Folder::find($listOnId))) $listOnIds[] = $listOnId;
            }
        }
        $tagIds = [];
        $reqTags = $request->tags;
        if (isset($reqTags) && !empty($reqTags)) {
            foreach ($request->tags as $tagId) {
                if (!empty(Tag::find($tagId))) $tagIds[] = $tagId;
            }
        }
        $thumbnail = $request->thumbnail;
        $cover = $request->cover;
        $params = [
            'title' => $request['title'],
            'description' => $request['description'],
            'cover' => $cover,
            'thumbnail' => $thumbnail,
            'content' => $this->processContent($request['content']),
            'set_on_id' => $setOnId,
            'list_on_ids' => $listOnIds,
            'published_at' => $request['published_at'],
            'priority' => $request['priority'],
            'keywords' => $request['keywords'],
            'is_sponsored' => $request['is_sponsored'],
            'created_by_id' => $request->user()->id,
            'tags' => $tagIds,
            'action' => $request['action'],
        ];

        $this->handleAdd($params);
        return $this->response200("OK!");
    }

    public function edit($id, Request $request)
    {
        $validation = Validator::make(
            $request->all(),
            [
                'title' => 'required',
                'description' => 'required',
                'content' => 'required',
                'set_on_id' => 'required',
                'list_on_ids' => [function ($attribute, $value, $fail) use ($request) {
                    if (in_array($request->set_on_id, $value)) {
                        return $fail('Không được list lên folder đã set!');
                    }
                }],
                'priority' => 'required',
                'action' => ['required', 'integer', 'min:0', 'max:3']
            ],
            [
                'title.required' => 'Tiêu đề không được để trống!',
                'description.required' => 'Mô tả không được để trống!',
                'content.required' => 'Nội dung không được để trống!',
                'set_on_id.required' => 'Set on không được để trống!',
                'priority.required' => 'Độ ưu tiên không được để trống!',
                'action' => 'Hành động không hợp lệ!'
            ]
        );
        if ($validation->fails()) {
            return $this->response422($validation->errors());
        }
        $p = Post::find($id);
        if (empty($p)) {
            return $this->response422('Không có bài này!');
        }
        $setOnId = $request->set_on_id;
        $setOnFolder = Folder::find($setOnId);
        if (empty($setOnFolder)) return $this->response422('Set on sai!');
        $listOnIds = [];
        $reqLists = $request->list_on_ids;
        if (isset($reqLists) && !empty($reqLists)) {
            foreach ($request->list_on_ids as $listOnId) {
                if (!empty(Folder::find($listOnId))) $listOnIds[] = $listOnId;
            }
        }
        $tagIds = [];
        $reqTags = $request->tags;
        if (isset($reqTags) && !empty($reqTags)) {
            foreach ($request->tags as $tagId) {
                if (!empty(Tag::find($tagId))) $tagIds[] = $tagId;
            }
        }
        $thumbnail = $request->thumbnail;
        $cover = $request->cover;
        $params = [
            'id' => $id,
            'title' => $request['title'],
            'description' => $request['description'],
            'cover' => $cover,
            'thumbnail' => $thumbnail,
            'content' => $this->processContent($request['content']),
            'set_on_id' => $setOnId,
            'list_on_ids' => $listOnIds,
            'published_at' => $request['published_at'],
            'priority' => $request['priority'],
            'keywords' => $request['keywords'],
            'is_sponsored' => $request['is_sponsored'],
            'action' => $request['action'],
            'tags' => $tagIds,
        ];

        $this->handleEdit(array_merge($params, ['user_id' => $request->user()->id]));
        return $this->response200("OK!");
    }

    public function handleEdit($params)
    {
        $p = Post::find($params['id']);
        $p->update(
            [
                'title' => $params['title'],
                'description' => $params['description'],
                'content' => $params['content'],
                'set_on_id' => $params['set_on_id'],
                'priority' => $params['priority'],
                'keywords' => serialize($params['keywords']),
                'is_sponsored' => isset($params['is_sponsored']) && $params['is_sponsored'],
                'cover' => $params['cover'] ?? '',
                'thumbnail' => $params['thumbnail'] ?? '',
            ]
        );
        $p->slug = Str::slug($p->title) . '-' . $p->id . '.html';
        if ($params['action'] == 0) {

        } elseif ($params['action'] == 1) {
            $p->status = 1;
        } elseif ($params['action'] == 2) {
            $p->status = 2;
            $p->published_by_id = $params['user_id'];
            if (isset($params['published_at']) && !empty($params['published_at'])) {
                $p->published_at = date("Y-m-d H:i:s", strtotime($params['published_at']));
            } else {
                $p->published_at = now();
            }
        } else {
            $p->status = 3;
        }
        if (isset($params['list_on_ids']) && !empty($params['list_on_ids'])) {
            $p->list_on_folders()->detach();
            $p->list_on_folders()->attach($params['list_on_ids']);
        }
        if (isset($params['tags']) && !empty($params['tags'])) {
            $p->tags()->detach();
            $p->tags()->attach($params['tags']);
        }
        $p->save();

        //Generate thumbs
        $path = $p->thumbnail;

        //Thumb ngang
        if (!File::exists($this->getResizedPath($path, 'horizontal'))) {
            $this->generateThumb($path, 384, 230, 'horizontal');
        }
        //Thumb doc
        if (!File::exists($this->getResizedPath($path, 'vertical'))) {
            $this->generateThumb($path, 384, 559, 'vertical');
        }
        //Thumb vuong
        if (!File::exists($this->getResizedPath($path, 'square'))) {
            $this->generateThumb($path, 404, 404, 'square');
        }
    }

    public function getResizedPath($path, $strAfter)
    {
        $path = public_path($path);
        $pathArr = explode('/', $path);
        $pathArrLen = count($pathArr);
        $imgName = $pathArr[$pathArrLen - 1];
        $imgNameArr = explode('.', $imgName);
        $imgNameArr['0'] = $imgNameArr['0'] . '-' . $strAfter;
        $imgName = implode('.', $imgNameArr);
        $pathArr[$pathArrLen - 1] = $imgName;
        $path = implode('/', $pathArr);

        return $path;
    }

    public function detail($id, Request $request)
    {
        $p = Post::find($id);
        if (empty($p)) {
            return $this->response422('Không có bài này!');
        }
        $request->post_area = 'cms_post_detail';
        return new PostResource($p);
    }

    public function delete(Request $request)
    {
        $validation = Validator::make(
            $request->all(),
            [
                'posts' => 'required'
            ],
            [
                'posts.required' => 'Danh sách xóa không được để trống!',
            ]
        );
        if ($validation->fails()) {
            return $this->response422($validation->errors());
        }
        $params = array_merge($request->only(['posts']));

        $this->handleDelete($params);
        return $this->response200("OK!");
    }

    public function publish(Request $request)
    {
        $validation = Validator::make(
            $request->all(),
            [
                'posts' => 'required'
            ],
            [
                'posts.required' => 'Danh sách duyệt không được để trống!',
            ]
        );
        if ($validation->fails()) {
            return $this->response422($validation->errors());
        }
        $params = array_merge($request->only(['posts']), ['published_by_id' => $request->user()->id]);

        $this->handlePublish($params);
        return $this->response200("OK!");
    }

    public function searchFolders(Request $request)
    {
        $name = $request->name;
        $folders = Folder::where('is_showed', true)->where('name', 'like', '%' . $name . '%')->get();
        $request->folder_area = 'cms_post_add';

        return FolderResource::collection($folders);
    }

    public function changeVerticalThumb($id, Request $request)
    {
        $validation = Validator::make(
            $request->all(),
            [
                'newVerticalPath' => 'required'
            ]
        );
        if ($validation->fails()) {
            return $this->response422($validation->errors());
        }
        $p = Post::find($id);
        if (empty($p)) {
            return $this->response422('Không có bài này!');
        }
        $newVerticalPath = $request->newVerticalPath;
        $path = $p->thumbnail;
        $pathArr = explode('/', $path);
        $pathArrLen = count($pathArr);
        $imgName = $pathArr[$pathArrLen - 1];
        $imgNameArr = explode('.', $imgName);
        $imgNameArr['0'] = $imgNameArr['0'] . '-' . 'vertical';
        $imgName = implode('.', $imgNameArr);
        $pathArr[$pathArrLen - 1] = $imgName;
        $verticalPath = implode('/', $pathArr);
        File::move(public_path($newVerticalPath), public_path($verticalPath));

        return $this->response200('OK');
    }

    public function changeSquareThumb($id, Request $request)
    {
        $validation = Validator::make(
            $request->all(),
            [
                'newSquarePath' => 'required'
            ]
        );
        if ($validation->fails()) {
            return $this->response422($validation->errors());
        }
        $p = Post::find($id);
        if (empty($p)) {
            return $this->response422('Không có bài này!');
        }
        $newVerticalPath = $request->newSquarePath;
        $path = $p->thumbnail;
        $pathArr = explode('/', $path);
        $pathArrLen = count($pathArr);
        $imgName = $pathArr[$pathArrLen - 1];
        $imgNameArr = explode('.', $imgName);
        $imgNameArr['0'] = $imgNameArr['0'] . '-' . 'square';
        $imgName = implode('.', $imgNameArr);
        $pathArr[$pathArrLen - 1] = $imgName;
        $verticalPath = implode('/', $pathArr);
        File::move(public_path($newVerticalPath), public_path($verticalPath));

        return $this->response200('OK');
    }

    public function handlePublish($params)
    {
        $posts = $params['posts'];
        $published_by_id = $params['published_by_id'];
        foreach ($posts as $p) {
            $post = Post::find($p);

            $post->update([
                'published_by_id' => $published_by_id,
                'status' => 2,
                'published_at' => now()
            ]);

            //Generate thumbs
            $path = $p->thumbnail;

            //Thumb ngang
            if (!File::exists($this->getResizedPath($path, 'horizontal'))) {
                $this->generateThumb($path, 384, 230, 'horizontal');
            }
            //Thumb doc
            if (!File::exists($this->getResizedPath($path, 'vertical'))) {
                $this->generateThumb($path, 384, 559, 'vertical');
            }
            //Thumb vuong
            if (!File::exists($this->getResizedPath($path, 'square'))) {
                $this->generateThumb($path, 404, 404, 'square');
            }
        }
    }

    public function processContent($content)
    {
        $return = trim($content);
        $return = preg_replace('/(<p><br><\/p>)+$/', '', $return);

        return $return;
    }

    public function handleAdd($params)
    {

        $p = Post::create(
            [
                'title' => $params['title'],
                'description' => $params['description'],
                'content' => $params['content'],
                'set_on_id' => $params['set_on_id'],
                'created_by_id' => $params['created_by_id'],
                'cover' => $params['cover'] ?? '',
                'thumbnail' => $params['thumbnail'] ?? '',
                'priority' => $params['priority'],
                'keywords' => serialize($params['keywords']),
                'is_sponsored' => isset($params['is_sponsored']) && $params['is_sponsored'],
            ]
        );
        $p->slug = Str::slug($p->title) . '-' . $p->id . '.html';
        if ($params['action'] == 0) {
            $p->status = 0;
        } elseif ($params['action'] == 1) {
            $p->status = 1;
        } else {
            $p->status = 2;
            $p->published_by_id = $params['created_by_id'];
            if (isset($params['published_at']) && !empty($params['published_at'])) {
                $p->published_at = date("Y-m-d H:i:s", strtotime($params['published_at']));
            } else {
                $p->published_at = now();
            }
        }

        //List on
        if (isset($params['list_on_ids']) && !empty($params['list_on_ids'])) {
            $p->list_on_folders()->detach();
            $p->list_on_folders()->attach($params['list_on_ids']);
        }

        //Tag
        if (isset($params['tags']) && !empty($params['tags'])) {
            $p->tags()->detach();
            $p->tags()->attach($params['tags']);
        }
        $p->save();

        //Generate thumbs
        $path = $p->thumbnail;
        //Thumb ngang
        $this->generateThumb($path, 384, 230, 'horizontal');
        //Thumb doc
        $this->generateThumb($path, 384, 559, 'vertical');
        //Thumb vuong
        $this->generateThumb($path, 404, 404, 'square');
    }

    public function generateThumb($path, $width, $height, $strAfter)
    {
        $path = public_path($path);
        $pathArr = explode('/', $path);
        $pathArrLen = count($pathArr);
        $intervention = Image::make($path);
        $imgName = $pathArr[$pathArrLen - 1];
        $imgNameArr = explode('.', $imgName);
        $imgNameArr['0'] = $imgNameArr['0'] . '-' . $strAfter;
        $imgName = implode('.', $imgNameArr);
        $pathArr[$pathArrLen - 1] = $imgName;
        $path = implode('/', $pathArr);

        $intervention->resize($width, $height)->save($path);
    }

    public function handleDelete($params)
    {
        $posts = $params['posts'];
        foreach ($posts as $p) {
            $post = Post::find($p);

            $post->delete();
        }
    }
}
