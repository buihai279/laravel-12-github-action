<?php

namespace App\Http\Controllers\CMS;

use App\Http\Controllers\Controller;
use App\Http\Resources\Comment as CommentResource;
use App\Jobs\Comment\Like;
use App\Jobs\Role\Edit;
use App\Model\Comment;
use App\Model\Post;
use App\Model\Role;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class CommentController extends Controller
{
    public function list($post_id, Request $request)
    {
        $post = Post::where('status', 2)->where('published_at', '<=', now())->where('id', $post_id)->first();
        if (empty($post)) {
            return $comments = collect([]);
        }
        $comments = $post->comments()->whereNull('parent_id')->paginate(8);
        $request->comment_area = 'front_parent';
        $comments = CommentResource::collection($comments);
        return $comments;
    }

    public function listChild($parent_id, Request $request)
    {
        $comment = Comment::where('id', $parent_id)->first();
        if (empty($comment)) {
            return $comments = collect([]);
        }
        $comments = $comment->child_comments()->paginate(8);
        $request->comment_area = 'front_child';
        $comments = CommentResource::collection($comments);
        return $comments;
    }

    public function add(Request $request)
    {
        $validation = Validator::make(
            $request->all(),
            [
                'post_slug' => 'required',
                'content' => 'required|min:1',
            ],
            [
                'post_slug' => 'Sản phẩm không được để trống!',
                'content.required' => 'Nội dung không được để trống!',
                'content.min' => 'Nội dung tối thiểu :min ký tự!',
            ]
        );
        if ($validation->fails()) {
            return $this->response422($validation->errors());
        }
        $p = Post::where('status', 2)->where('published_at', '<=', now())->where('slug', $request->post_slug)->first();
        if (empty($p)) {
            return $this->response422('Bài viết không tồn tại!');
        }
        $params = [
            'post_id' => $p->id,
            'content' => $request['content'],
            'parent_id' => $request->parent_id,
            'created_by_id' => auth()->user()->id
        ];
        \App\Jobs\Comment\Add::dispatch($params);

        return $this->response200('OK!');
    }

    public function edit($id, Request $request)
    {
        $validation = Validator::make(
            $request->all(),
            [
                'name' => 'required',
            ],
            [
                'name.required' => 'Tên nhóm quyền không được để trống!',
            ]
        );
        if ($validation->fails()) {
            return $this->response422($validation->errors());
        }
        $role = Role::find($id);
        if (empty($role)) {
            return $this->response422("Không có role!");
        }
        $params = array_merge($request->only(['name', 'permissions']), ['id' => $id]);

        Edit::dispatch($params);
        return $this->response200("OK!");
    }

    public function delete($comment_id, Request $request)
    {
        $comment = Comment::find($comment_id);
        if (empty($comment)) {
            return $this->response422("Không có role!");
        }
        $params = ['id' => $comment_id];

        \App\Jobs\Comment\Delete::dispatch($params);
        return $this->response200("OK!");
    }

    public function like($comment_id)
    {
        Like::dispatch(['comment_id' => $comment_id, 'created_by_id' => auth()->user()->id]);

        return $this->response200("OK!");
    }
}
