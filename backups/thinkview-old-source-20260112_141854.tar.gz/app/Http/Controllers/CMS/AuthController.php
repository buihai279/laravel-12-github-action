<?php

namespace App\Http\Controllers\CMS;

use App\Http\Controllers\Controller;
use App\Http\Resources\User as UserResource;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

class AuthController extends Controller
{
    public function login(Request $request)
    {
        $validation = Validator::make(
            $request->all(),
            [
                'email' => 'required|email',
                'password' => 'required',
            ]
        );
        if ($validation->fails()) {
            return $this->response422($validation->errors());
        }
        $user = User::where('email', $request->email)->first();

        if (!$user || !Hash::check($request->password, $user->password)) {
            return $this->response422('These credentials do not match our records.');
        }
        $token = $user->createToken('cms')->plainTextToken;

        return $this->response200($token);
    }

    public function logout(Request $request)
    {
        $request->user()->tokens()->delete();

        return $this->response200('OK!');
    }

    public function user(Request $request)
    {
        $user = $request->user();
        $request->user_area = 'cms_auth_user';

        return new UserResource($user);
    }

    public function changePassword(Request $request)
    {
        $validation = Validator::make(
            $request->all(),
            [
                'old_password' => ['required', function ($attribute, $value, $fail) use ($request) {
                    if (!Hash::check($value, $request->user()->password)) {
                        return $fail('Mật khẩu không đúng!');
                    }
                }],
                'new_password' => 'required|string|min:6',
            ],
            [
                'new_password.required' => 'Password không được để trống!',
                'new_password.min' => 'Password tối thiểu :min kí tự!',
            ]
        );
        if ($validation->fails()) {
            return $this->response422($validation->errors());
        }
        $user = $request->user();
        $user->update([
            'password' => bcrypt($request->new_password),
        ]);

        return $this->response200("OK!");
    }
}
