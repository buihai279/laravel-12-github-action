<?php

namespace App\Http\Controllers\CMS;

use App\Http\Controllers\Controller;
use App\Http\Resources\User as UserResource;
use App\Jobs\User\Add;
use App\Jobs\User\Delete;
use App\Jobs\User\Edit;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class UserController extends Controller
{
    public function list(Request $request)
    {
        $search = $request->search;
        $filter = $request->filter;
        $role_ids = $filter['role_ids'];
        $users = User::where('name', 'like', '%' . $search . '%');
        if (isset($role_ids) && !empty($role_ids)) {
            $users->whereIn('role_id', $role_ids);
        }
        $users = $users->paginate(10);
        $request->user_area = 'cms_list_users';

        return UserResource::collection($users);
    }

    public function add(Request $request)
    {
        $validation = Validator::make(
            $request->all(),
            [
                'name' => 'required|max:255|string',
                'email' => 'required|email|string|unique:users|max:255',
                'password' => 'required|string|min:6',
                'role_id' => 'required|integer',
            ],
            [
                'name.required' => 'Tên người dùng không được để trống!',
                'email.required' => 'Email không được để trống!',
                'email.unique' => 'Email đã tồn tại!',
                'email.email' => 'Email không hợp lệ!',
                'password.required' => 'Password không được để trống!',
                'password.min' => 'Password tối thiểu :min kí tự!',
                'role_id.required' => 'Nhóm quyền không được để trống!',
            ]
        );
        if ($validation->fails()) {
            return $this->response422($validation->errors());
        }
        $params = array_merge($request->only(['name', 'email', 'password', 'role_id']), ['created_by_id' => $request->user()->id]);

        Add::dispatch($params);
        return $this->response200("OK!");
    }

    public function edit($id, Request $request)
    {
        $validation = Validator::make(
            $request->all(),
            [
                'name' => 'required|max:255|string',
                'email' => 'required|email|string|max:255',
                'role_id' => 'required|integer',
            ],
            [
                'name.required' => 'Tên người dùng không được để trống!',
                'email.required' => 'Email không được để trống!',
                'email.unique' => 'Email đã tồn tại!',
                'email.email' => 'Email không hợp lệ!',
                'role_id.required' => 'Nhóm quyền không được để trống!',
            ]
        );
        if ($validation->fails()) {
            return $this->response422($validation->errors());
        }
        $user = User::find($id);
        if (empty($user)) {
            return $this->response422("Không có user!");
        }
        $params = array_merge($request->only(['name', 'email', 'role_id']), ['id' => $id]);

        Edit::dispatch($params);
        return $this->response200("OK!");
    }

    public function delete($id, Request $request)
    {
        $user = User::find($id);
        if (empty($user)) {
            return $this->response422("Không có user!");
        }
        $params = ['id' => $id];

        Delete::dispatch($params);
        return $this->response200("OK!");
    }
}
