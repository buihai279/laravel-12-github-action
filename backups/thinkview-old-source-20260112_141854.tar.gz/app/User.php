<?php

namespace App;

use App\Model\Comment;
use App\Model\Post;
use App\Model\Role;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    use Notifiable, HasApiTokens;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'password', 'avatar', 'created_by_id', 'role_id', 'login_by', 'front_info_updated_at'
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    public function role()
    {
        return $this->belongsTo(Role::class, 'role_id');
    }

    public function likes()
    {
        return $this->belongsToMany(Comment::class, 'likes', 'created_by_id', 'comment_id');
    }

    public function seenPosts()
    {
        return $this->belongsToMany(Post::class, 'user_seen_posts', 'user_id', 'post_id');
    }
}
