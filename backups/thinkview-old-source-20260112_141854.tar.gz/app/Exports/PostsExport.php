<?php

namespace App\Exports;

use App\Model\Post;
use Illuminate\Support\Facades\Cache;
use Maatwebsite\Excel\Concerns\FromCollection;

class PostsExport implements FromCollection
{
    protected $params;

    public function __construct($params)
    {
        $this->params = $params;
    }

    public function collection()
    {
        ini_set('max_execution_time', 3000);
        set_time_limit(3000);
        $params = $this->params;
        $search = $params['search'];
        $filter = $params['filter'];
        $sort = $params['sort'];
        $posts = Post::where(function ($q) use ($search) {
            $q->orWhere('title', 'like', '%' . $search . '%')->orWhere('description', 'like', '%' . $search . '%');
        });
        if (isset($filter['folder']) && !empty($filter['folder'])) {
            $posts = $posts->where(function ($q) use ($filter) {
                $q->whereHas('list_on_folders', function ($qq) use ($filter) {
                    $qq->whereIn('folder_id', $filter['folder']);
                })->orWhereIn('set_on_id', $filter['folder']);
            });
        }
        if (isset($filter['status']) && !empty($filter['status'])) {
            $posts = $posts->where(function ($q) use ($filter) {
                $q->orWhereIn('status', $filter['status']);
            });
        }
        if (isset($filter['is_sponsored']) && !empty($filter['is_sponsored'])) {
            if ($filter['is_sponsored'] === 1) $posts = $posts->where('is_sponsored', 1);
            elseif ($filter['is_sponsored'] === 0) $posts = $posts->where('is_sponsored', 0);
        }
        if (isset($filter['created_by_id']) && !empty($filter['created_by_id'])) {
            $posts->whereIn('created_by_id', $filter['created_by_id']);
        }
        if (isset($filter['from_date']) && !empty($filter['from_date']) && isset($filter['to_date']) && !empty($filter['to_date'])) {
            $from = new \DateTime($filter['from_date']);
            $to = (new \DateTime($filter['to_date']))->modify('+1 day');
            $posts = $posts->whereBetween('created_at', [$from, $to]);
        }
        if (isset($sort) && !empty($sort) && $sort == 2) {
            $posts = $posts->orderBy('id', 'asc');
        } else {
            $posts = $posts->orderBy('id', 'desc');
        }
        $posts = $posts->get();
        $results = [['Url', 'Views', 'Time']];
        foreach ($posts as $post) {
            $id = $post->id;
            $views = Cache::get("ga-$id-month") ?? 'N/A';
            $time = $post->created_at->format('H:i d/m/Y');
            $results[] = ['https://thinkview.vn/' . $post->slug, $views, $time];
        }
        $results = collect($results);
        return $results;
    }
}
