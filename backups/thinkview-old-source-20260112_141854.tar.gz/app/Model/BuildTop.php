<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class BuildTop extends Model
{
    protected $table = 'build_tops';

    public function posts()
    {
        return $this->belongsToMany(Post::class, 'build_tops_posts', 'build_top_id', 'post_id');
    }
}
