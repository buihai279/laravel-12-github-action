<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Notification extends Model
{
    use HasFactory;

    protected $fillable = ['url', 'type', 'content', 'user_id', 'is_read', 'group_by_id', 'created_by_ids', 'object_ids', 'changed_at'];
}
