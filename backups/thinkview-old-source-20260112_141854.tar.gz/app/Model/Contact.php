<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Contact extends Model
{
    protected $fillable = ['name', 'position', 'phone', 'email', 'partner_id'];

    public function partner()
    {
        return $this->belongsTo(Partner::class, 'partner_id');
    }
}
