<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Folder extends Model
{
    protected $fillable = ['name', 'parent_id', 'level', 'slug', 'created_by_id', 'is_showed', 'slot', 'background_changed_at', 'background'];

    public function children()
    {
        return $this->hasMany(Folder::class, 'parent_id');
    }

    public function parent()
    {
        return $this->belongsTo(Folder::class, 'parent_id');
    }

    public function buildPosts()
    {
        return $this->belongsToMany(Post::class, 'build_for_folders', 'folder_id', 'post_id');
    }

    public function setOnPosts()
    {
        return $this->hasMany(Post::class, 'set_on_id');
    }

    public function listOnPosts()
    {
        return $this->belongsToMany(Post::class, 'posts_list_on_folders', 'folder_id', 'post_id');
    }
}
