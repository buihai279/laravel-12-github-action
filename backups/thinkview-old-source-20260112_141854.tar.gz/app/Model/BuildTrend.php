<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class BuildTrend extends Model
{
    public function posts()
    {
        return $this->belongsToMany(Post::class, 'build_trends_posts', 'build_trend_id', 'post_id');
    }
}
