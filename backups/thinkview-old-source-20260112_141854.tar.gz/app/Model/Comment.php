<?php

namespace App\Model;

use App\User;
use Illuminate\Database\Eloquent\Model;

class Comment extends Model
{
    protected $table = 'comments';

    protected $fillable = ['content', 'created_by_id', 'status', 'post_id', 'parent_id'];

    public function created_user()
    {
        return $this->belongsTo(User::class, 'created_by_id');
    }

    public function parent_comment()
    {
        return $this->belongsTo(Comment::class, 'parent_id');
    }

    public function post()
    {
        return $this->belongsTo(Post::class, 'post_id');
    }

    public function child_comments()
    {
        return $this->hasMany(Comment::class, 'parent_id');
    }

    public function liked_users()
    {
        return $this->belongsToMany(User::class, 'likes', 'comment_id', 'created_by_id');
    }
}
