<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class BuildHot extends Model
{
    protected $table = 'build_hots';

    public function posts()
    {
        return $this->belongsToMany(Post::class, 'build_hots_posts', 'build_hot_id', 'post_id');
    }
}
