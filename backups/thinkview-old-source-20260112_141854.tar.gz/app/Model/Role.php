<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Role extends Model
{
    protected $fillable = [
        'name', 'permissions', 'created_by_id'
    ];

    public function permissions()
    {
        return !empty($this->permissions) ? unserialize($this->permissions) : [];
    }
}
