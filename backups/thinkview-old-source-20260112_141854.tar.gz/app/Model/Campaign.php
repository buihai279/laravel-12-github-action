<?php

namespace App\Model;

use App\User;
use Illuminate\Database\Eloquent\Model;

class Campaign extends Model
{
    protected $fillable = ['name', 'partner_id', 'start_date', 'end_date', 'end_clicks', 'end_impressions', 'created_by_id', 'clicks', 'impressions'];

    public function partner()
    {
        return $this->belongsTo(Partner::class, 'partner_id');
    }

    public function banners()
    {
        return $this->hasMany(Banner::class, 'campaign_id');
    }

    public function posts()
    {
        return $this->belongsToMany(Campaign::class, 'campaigns_posts', 'post_id', 'campaign_id');
    }

    public function created_by_user()
    {
        return $this->belongsTo(User::class, 'created_by_id');
    }
}
