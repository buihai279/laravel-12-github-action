<?php

namespace App\Model;

use App\User;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Post extends Model
{
    use HasFactory;

    protected $table = 'posts';

    protected $fillable = ['title', 'description', 'content', 'set_on_id', 'created_by_id', 'published_at', 'priority', 'keywords', 'slug', 'is_sponsored', 'published_by_id', 'status', 'cover', 'thumbnail'];

    public function set_on_folder()
    {
        return $this->belongsTo(Folder::class, 'set_on_id');
    }

    public function list_on_folders()
    {
        return $this->belongsToMany(Folder::class, 'posts_list_on_folders', 'post_id', 'folder_id');
    }

    public function tags()
    {
        return $this->belongsToMany(Tag::class, 'posts_tags', 'post_id', 'tag_id');
    }

    public function comments()
    {
        return $this->hasMany(Comment::class, 'post_id');
    }

    public function campaigns()
    {
        return $this->belongsToMany(Post::class, 'campaigns_posts', 'campaign_id', 'post_id');
    }

    public function created_user()
    {
        return $this->belongsTo(User::class, 'created_by_id');
    }
}
