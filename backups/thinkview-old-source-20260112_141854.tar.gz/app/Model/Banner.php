<?php

namespace App\Model;

//use App\BannerImages;
use Illuminate\Database\Eloquent\Model;

class Banner extends Model
{
    protected $fillable = ['type', 'image_pc', 'image_mb', 'impressions_pc', 'impressions_mb', 'clicks_pc', 'clicks_mb', 'link', 'slot', 'folder_id', 'campaign_id'];

    public function campaign()
    {
        return $this->belongsTo(Campaign::class, 'campaign_id');
    }
}
