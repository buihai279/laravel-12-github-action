<?php

namespace App\Libs;

use Google_Client;

class RenewAccessToken
{
    public static function renew()
    {
        $client = new Google_Client();
        $client->setAuthConfig(storage_path('app/ga/ThinkViewCounter-865f63e3a757.json'));
        $client->addScope('https://www.googleapis.com/auth/analytics.readonly');
        $client->setApplicationName("GoogleAnalytics");
        $client->refreshTokenWithAssertion();
        $token = $client->getAccessToken();
        $accessToken = $token['access_token'];
        session(['access_token' => $accessToken]);
    }
}


