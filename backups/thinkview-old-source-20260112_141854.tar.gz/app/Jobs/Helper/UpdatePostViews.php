<?php

namespace App\Jobs\Helper;

use App\Libs\RenewAccessToken;
use App\Model\Post;
use Carbon\Carbon;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Http;

class UpdatePostViews implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public function handle()
    {
        $posts = Post::where('status', 2)->get();
//        $pagePaths = "";
//        foreach ($posts->chunk(10) as $chunk) {
//            foreach ($chunk as $post) {
//                $slug = $post->slug;
//                $id = $post->id;
//                if (!Cache::has("ga-$id-month")) {
//                    $pagePaths .= "ga%3ApagePath%3D%3D%2F$slug,";
//                }
//            }
//            $pagePaths = rtrim($pagePaths, ",");
//            UpdatePostViewsChunking::dispatch(['pagePaths' => $pagePaths]);
//        }
        RenewAccessToken::renew();
        $accessToken = session('access_token');
        $startDateAll = '2020-10-01';
        $resultPostsMonth = Http::get("https://www.googleapis.com/analytics/v3/data/ga?ids=ga%3A230988093&start-date=30daysAgo&end-date=today&metrics=ga%3Apageviews&dimensions=ga%3ApageTitle&filters=ga%3ApagePath%3D%40.html%3Bga%3ApagePath%3D%40-&access_token=$accessToken");
        foreach ($resultPostsMonth->json()['rows'] as $postView) {
            $title = str_replace(" - ThinkView", "", $postView[0]);
            $post = Post::where('title', $title)->first();
            if (!empty($post)) {
                $id = $post->id;
                Cache::put("ga-$id-month", $postView[1], 86400);
            }
        }
        $resultPostsAll = Http::get("https://www.googleapis.com/analytics/v3/data/ga?ids=ga%3A230988093&start-date=$startDateAll&end-date=today&metrics=ga%3Apageviews&dimensions=ga%3ApageTitle&filters=ga%3ApagePath%3D%40.html%3Bga%3ApagePath%3D%40-&access_token=$accessToken");
        foreach ($resultPostsAll->json()['rows'] as $postView) {
            $title = str_replace(" - ThinkView", "", $postView[0]);
            $post = Post::where('title', $title)->first();
            if (!empty($post)) {
                $id = $post->id;
                Cache::put("ga-$id-all", $postView[1], 86400);
            }
        }
    }

//    public function post_ids($resultPosts)
//    {
//        $post_ids = [];
//        foreach ($resultPosts->json()['rows'] as $postView) {
//            if (strpos($postView[0], '?fbclid=') === false) {
//                $arr = explode('-', explode('.', $postView[0])[0]);
//                $len = count($arr);
//                $id = $arr[$len - 1];
//                if (!in_array($id, $post_ids)) $post_ids[] = $id;
//            }
//        }
//        foreach ($post_ids as $post_id) {
//            $id = $post_id;
//            $post_id = [];
//            $post_id['id'] = $id;
//            $post_id['views'] = 0;
//            foreach ($resultPosts->json()['rows'] as $postView) {
//                if (strpos($postView[0], '-' . $post_id['id'] . '.html') !== false) {
//                    $post_id['views'] += $postView[1];
//                }
//            }
//        }
//        return $post_ids;
//    }
}
