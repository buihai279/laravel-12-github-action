<?php

namespace App\Jobs\Helper;

use App\Libs\RenewAccessToken;
use App\Model\Post;
use Carbon\Carbon;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Http;

class UpdatePostViewsChunking implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    private $params;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct($params)
    {
        if (empty($params)) {
            return;
        }
        $this->params = $params;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        RenewAccessToken::renew();
        $accessToken = session('access_token');
        $params = $this->params;
        $pagePaths = $params['pagePaths'];
        $now = Carbon::now();
        $endDate = $now->format('Y-m-d');
        $startDateMonth = $now->firstOfMonth()->format('Y-m-d');
        $startDateAll = '2020-10-01';
        $responseMonth = Http::get("https://www.googleapis.com/analytics/v3/data/ga?ids=ga%3A230988093&start-date=$startDateMonth&end-date=$endDate&metrics=ga%3Apageviews&dimensions=ga%3ApagePath&filters=$pagePaths&access_token=$accessToken");
        if (isset($responseMonth->json()['rows'])) {
            $viewsMonth = $responseMonth->json()['rows'];
            $responseAll = Http::get("https://www.googleapis.com/analytics/v3/data/ga?ids=ga%3A230988093&start-date=$startDateAll&end-date=$endDate&metrics=ga%3Apageviews&dimensions=ga%3ApagePath&filters=$pagePaths&access_token=$accessToken");
            $viewsAll = $responseAll->json()['rows'];
            for ($i = 0; $i < count($viewsMonth); $i++) {
                $slug = ltrim($viewsMonth[$i][0], '/');
                $post = Post::where('slug', $slug)->first();
                $id = $post->id;
                if (!Cache::has("ga-$id-month")) {
                    Cache::put("ga-$id-month", $viewsMonth[$i][1], 86400);
                }
                if (!Cache::has("ga-$id-all")) {
                    Cache::put("ga-$id-all", $viewsAll[$i][1], 86400);
                }
            }
        }
    }
}
