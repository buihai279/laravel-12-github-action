<?php

namespace App\Jobs\Comment;

use App\Events\LikeComment;
use App\Model\Comment;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\DB;

class Like implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    private $params;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct($params)
    {
        if (empty($params)) {
            return;
        }
        $this->params = $params;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $params = $this->params;
        $like = DB::table('likes')->where('created_by_id', $params['created_by_id'])->where('comment_id', $params['comment_id']);
        $isLiked = !empty($like->first());
        if (!$isLiked) {
            DB::table('likes')->insert(['created_by_id' => $params['created_by_id'], 'comment_id' => $params['comment_id'], 'created_at' => now(), 'updated_at' => now()]);
        } else {
            $like->delete();
        }
        $commentCreatedBy = Comment::find($params['comment_id'])->created_by_id;
        if ($commentCreatedBy !== $params['created_by_id']) {
            $params['isLiked'] = !$isLiked;
            event(new LikeComment($params));
        }
    }
}
