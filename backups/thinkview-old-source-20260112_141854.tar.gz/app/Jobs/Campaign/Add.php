<?php

namespace App\Jobs\Campaign;

use App\Model\Banner;
use App\Model\Campaign;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\DB;

class Add implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    private $params;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct($params)
    {
        if (empty($params)) {
            return;
        }
        $this->params = $params;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        DB::beginTransaction();
        try {
            $params = $this->params;
            $banners = $params['banners'];
            unset($params['banners']);
            $campaign = Campaign::create($params);
            if (isset($banners) && !empty($banners)) {
                foreach ($banners as $banner) {
                    $banner['campaign_id'] = $campaign->id;
                    Banner::create($banner);
                }
            }
            DB::commit();
        } catch (\Exception $e) {
            DB::rollback();
            die(json_encode($e->getMessage()));
        }
    }
}
