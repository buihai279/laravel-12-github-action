<?php

namespace App\Jobs\Folder;

use App\Model\Folder;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Str;

class Edit implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    private $params;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct($params)
    {
        if (empty($params)) {
            return;
        }
        $this->params = $params;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $params = $this->params;

        $folder = Folder::find($params['id']);
        $folder->update([
            'name' => $params['name'],
            'is_showed' => (isset($params['is_showed']) && $params['is_showed']) ? true : false,
        ]);
        $slug = $folder->slug;
        $slug = explode('/', $slug);
        $len = count($slug);
        $slug[$len - 1] = Str::slug($folder->name);
        $slug = implode('/', $slug);
        $folder->slug = $slug;
        $folder->save();
        //Change folder children slug
        $children = $folder->children;
        foreach ($children as $child) {
            $slugChild = $child->slug;
            $slugChildArr = explode('/', $slugChild);
            $len = count($slugChildArr);
            $slugChildArr[$len - 2] = $slug;
            $slugChild = implode('/', $slugChildArr);

            $child->update(['slug' => $slugChild]);
        }
    }
}
