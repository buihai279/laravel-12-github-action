<?php

namespace App\Policies;

use App\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class RolePolicy
{
    use HandlesAuthorization;

    /**
     * Create a new policy instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    public function add(User $user)
    {
        return in_array('roles.add', $user->role->permissions());
    }

    public function edit(User $user)
    {
        return in_array('roles.edit', $user->role->permissions());
    }

    public function list(User $user)
    {
        return in_array('roles.list', $user->role->permissions());
    }

    public function delete(User $user)
    {
        return in_array('roles.delete', $user->role->permissions());
    }
}
