<?php

namespace App\Policies;

use App\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class BuildPolicy
{
    use HandlesAuthorization;

    /**
     * Create a new policy instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    public function top(User $user)
    {
        return in_array('builds.top', $user->role->permissions());
    }

    public function hot(User $user)
    {
        return in_array('builds.hot', $user->role->permissions());
    }

    public function trend(User $user)
    {
        return in_array('builds.trend', $user->role->permissions());
    }
}
