<?php

namespace App\Policies;

use App\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class FolderPolicy
{
    use HandlesAuthorization;

    /**
     * Create a new policy instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    public function add(User $user)
    {
        return in_array('folders.add', $user->role->permissions());
    }

    public function edit(User $user)
    {
        return in_array('folders.edit', $user->role->permissions());
    }

    public function list(User $user)
    {
        return in_array('folders.list', $user->role->permissions());
    }

    public function delete(User $user)
    {
        return in_array('folders.delete', $user->role->permissions());
    }
}
