<?php

namespace App\Policies;

use App\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class PostPolicy
{
    use HandlesAuthorization;

    /**
     * Create a new policy instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    public function add(User $user)
    {
        return in_array('posts.add', $user->role->permissions());
    }

    public function edit(User $user)
    {
        return in_array('posts.edit', $user->role->permissions());
    }

    public function list_editor(User $user)
    {
        return in_array('posts.list_editor', $user->role->permissions());
    }

    public function list_writer(User $user)
    {
        return in_array('posts.list_writer', $user->role->permissions());
    }

    public function delete(User $user)
    {
        return in_array('posts.delete', $user->role->permissions());
    }

    public function publish(User $user)
    {
        return in_array('posts.publish', $user->role->permissions());
    }
}
