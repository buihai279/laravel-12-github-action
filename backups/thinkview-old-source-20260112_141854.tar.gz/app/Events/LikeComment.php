<?php

namespace App\Events;

use App\Model\Comment;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Broadcasting\PrivateChannel;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;

class LikeComment implements ShouldBroadcast
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public $params;

    public function __construct($params)
    {
        $this->params = $params;
    }

    public function broadcastOn()
    {
        $params = $this->params;
        $user_id = Comment::find($params['comment_id'])->created_by_id;
        return new PrivateChannel('user.' . $user_id);
    }
}
