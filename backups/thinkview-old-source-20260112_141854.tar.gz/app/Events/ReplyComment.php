<?php

namespace App\Events;

use App\Model\Comment;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Broadcasting\PrivateChannel;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class ReplyComment implements ShouldBroadcast
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public $params;

    public function __construct($params)
    {
        $this->params = $params;
    }

    public function broadcastOn()
    {
        $params = $this->params;
        $user_id = Comment::find($params['parent_id'])->created_by_id;
        return new PrivateChannel('user.' . $user_id);
    }
}
