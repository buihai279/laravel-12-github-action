<?php

return [
    'builds' => [
        'name' => 'Build trang',
        'policies' => 'Policies\BuildPolicy',
        'permission' => [
            'top' => 'Build top',
            'hot' => 'Build hot',
            'trend' => 'Build trend',
        ],
    ],
    'folders' => [
        'name' => 'Thư mục',
        'policies' => 'Policies\FolderPolicy',
        'permission' => [
            'add' => 'Thêm mới thư mục',
            'edit' => 'Chỉnh sửa thư mục',
            'list' => 'Xem danh sách thư mục',
            'delete' => 'Xóa thư mục',
        ],
    ],
    'posts' => [
        'name' => 'Bài viết',
        'policies' => 'Policies\PostPolicy',
        'permission' => [
            'add' => 'Thêm mới bài viết',
            'edit' => 'Chỉnh sửa bài viết',
            'list_writer' => 'Danh sách bài đã viết',
            'list_editor' => 'Danh sách bài đã được duyệt',
            'delete' => 'Xóa thành bài viết',
            'publish' => 'Duyệt bài viết'
        ],
    ],
    'users' => [
        'name' => 'Thành viên',
        'policies' => 'Policies\UserPolicy',
        'permission' => [
            'add' => 'Thêm mới thành viên',
            'edit' => 'Chỉnh sửa thành viên',
            'list' => 'Xem danh sách thành viên',
            'delete' => 'Xóa thành viên',
        ],
    ],
    'roles' => [
        'name' => 'Vai trò',
        'policies' => 'Policies\RolePolicy',
        'permission' => [
            'add' => 'Thêm mới nhóm quyền',
            'edit' => 'Chỉnh sửa nhóm phân quyền',
            'list' => 'Xem danh sách phân quyền',
            'delete' => 'Xóa nhóm phân quyền',
        ],
    ],
];
